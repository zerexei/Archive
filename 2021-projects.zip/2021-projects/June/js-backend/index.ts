import express from "express";

const app = express();

app.listen(3001, () => console.log("listening: 3001"));
