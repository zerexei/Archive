// TODO: dynamic units
// TODO: 8 sides
// TODO: improve code

// range inputs
const inputs = {
  topLeft: document.querySelector(".top-left-border"),
  topRight: document.querySelector(".top-right-border"),
  bottomLeft: document.querySelector(".bottom-left-border"),
  bottomRight: document.querySelector(".bottom-right-border"),
};

// reset values on page refresh
inputs.topLeft.value = 0;
inputs.topRight.value = 0;
inputs.bottomLeft.value = 0;
inputs.bottomRight.value = 0;

// get border radius
function getRadius(inputs) {
  return {
    topLeft: inputs.topLeft.value,
    topRight: inputs.topRight.value,
    bottomLeft: inputs.bottomLeft.value,
    bottomRight: inputs.bottomRight.value,
  };
}

// get border radius css property
function getBorderRadiusCss(radius) {
  return `border-radius: ${radius.topLeft}% ${radius.topRight}% ${radius.bottomRight}% ${radius.bottomLeft}%`;
}

// copy string to clipboard
function copyStringToClipboard(str) {
  const el = document.createElement("textarea");
  el.value = str;
  el.setAttribute("readonly", "");
  el.style = { position: "absolute", left: "-9999px" };
  document.body.appendChild(el);
  el.select();
  document.execCommand("copy");
  document.body.removeChild(el);
}

// onmousemove update border radius
function update() {
  const radius = getRadius(inputs);
  document.querySelector(".border").style = getBorderRadiusCss(radius);
  document.querySelector("#code").innerText = getBorderRadiusCss(radius) + ";";
}

function generate() {
  const radius = getRadius(inputs);
  const str = `.border-radius {
  border: 1px solid #000;
  ${getBorderRadiusCss(radius)};
}`;

  copyStringToClipboard(str);
}
