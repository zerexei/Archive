<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6 w-1/3 mx-auto">
                    {{-- LABEL --}}
                    <h2 class="mb-4 text-4xl">Create a Post</h2>
                    <form action="{{ route('posts.update', $post) }}" method="POST">
                        @method('PATCH')
                        @csrf

                        {{-- ERRORS --}}
                        @include('includes.errors')

                        {{-- TITLE --}}
                        <div class="mb-4">
                            <label for="title" class="block text-sm text-gray-700">Title</label>
                            <input name="title" value="{{$post->title}}" type="text"
                                class="w-full mt-1 p-2 text-gray-900 border rounded">
                        </div>

                        {{-- BODY --}}
                        <div class="mb-4">
                            <label for="body" class="block text-sm text-gray-700">Body</label>
                            <textarea name="body" class="w-full text-gray-900 rounded resize-none" rows="5">
                                {{$post->body}}
                            </textarea>
                        </div>
                        {{-- SUBMIT --}}
                        <div class="mb-4">
                            <button
                                class="w-full py-2 px-4 text-white font-bold bg-blue-400 rounded hover:bg-blue-500">Post</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
