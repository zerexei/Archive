<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6">
                    <div class="w-full flex justify-center gap-5 flex-wrap">
                        @forelse ($posts as $post)
                        <div class="w-1/4 p-4 border-r border-b border-red-400">
                            <h2 class="mb-2 text-xl">{{$post->title}}</h2>
                            <p class="mb-1 text-sm text-gray-900">
                                {{$post->body}}
                            </p>
                            <p class="text-xs text-gray-700">author: {{$post->user->name}}</p>
                        </div>
                        @empty
                        <p>There is no post available.</p>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
