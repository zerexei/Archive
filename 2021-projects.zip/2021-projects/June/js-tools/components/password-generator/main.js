// select all range and result
const maxSpecials = document.querySelector("#maxSpecials");
const maxNumbers = document.querySelector("#maxNumbers");
const length = document.querySelector("#length");
const result = document.querySelector("#result");

// reset values
maxSpecials.value = 1;
maxNumbers.value = 1;
length.value = 8;

// set range indicator
maxSpecials.addEventListener("input", () => {
	maxSpecials.parentNode.querySelector("span").innerHTML = maxSpecials.value;
});
maxNumbers.addEventListener("input", () => {
	maxNumbers.parentNode.querySelector("span").innerHTML = maxNumbers.value;
});
length.addEventListener("input", () => {
	length.parentNode.querySelector("span").innerHTML = length.value;
});

function generate() {
	// convert to number
	const iMaxNumbers = Number(maxSpecials.value);
	const iMaxSpecials = Number(maxNumbers.value);
	const iLength = Number(length.value);

	// set max letters
	const maxLetters = iLength - (iMaxSpecials + iMaxNumbers);

	// check if max letter is not less than zero
	if (maxLetters <= 0) {
		alert("Special or numeric character exceeds the limit");
		return;
	}

	// set tokens
	let pattern = [];
	const specials = ["!", "@", "#", "$", "%", "^", "&", "*", "|", "-"];
	const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
	const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
		.split("");

	// check if max special character is greater than zero
	if (maxSpecials.value > 0) {
		pattern = [...pattern, ...shuffle(specials).splice(-iMaxSpecials)];
	}

	// check if max numeric character is greater than zero
	if (maxNumbers.value > 0) {
		pattern = [...pattern, ...shuffle(numbers).splice(-iMaxNumbers)];
	}

	// add letters then shuffle patterns
	pattern = shuffle([...pattern, ...shuffle(letters).splice(-maxLetters)]);

	// convert to string and remove comas then show result
	result.value = pattern.toString().replace(/,/g, "");

	//? more pattern
	// const pattern1 = [...specials, ...numbers, ...letters];
	// pattern....
}

//? copy generated token
// function copy() {
// 	input.select();
// 	input.setSelectionRange(0, 99999);
// 	document.execCommand("copy");
// 	alert("Copied: " + input.value);
// }

// Fisher-Yates shuffle
function shuffle(array) {
	const arrayLength = array.length - 1;

	for (let i = arrayLength; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[array[i], array[j]] = [array[j], array[i]];
	}

	return array;
}
