# crud-prisma
simple crud back end using express and prisma
