import express from "express";
import { Collection, MongoClient } from "mongodb";

import { config } from "./config";

const app = express();

const uri = config.database.uri;
const client = new MongoClient(uri, {
	useNewUrlParser: true,
	useUnifiedTopology: true,
});

async function run(call: unknown) {
	try {
		await client.connect();
		const database = client.db("sample_mflix");
		const collection = database.collection("movies");
		return await call(collection);
	} catch (error) {
		console.log(error);
	} finally {
		// Ensures that the client will close when you finish/error
		await client.close();
	}
}

run(async (collection: Collection) => {
	const pizzaDocuments = [
		{ name: "Sicilian pizza", shape: "square" },
		{ name: "New York pizza", shape: "round" },
		{ name: "Grandma pizza", shape: "square" },
	];
	return await collection.insertMany(pizzaDocuments);
});

app.listen(3001, () => console.log("Listening..."));
