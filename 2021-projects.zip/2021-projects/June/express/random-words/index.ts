import express from "express";

require('dotenv').config();

const app = express();

app.listen(80, () => console.log("Listening..."));
