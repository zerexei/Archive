# sort numbers, get index 0-1 then return sum 
def sum_two_smallest_numbers(numbers):
    return sum(sorted(numbers)[:2])