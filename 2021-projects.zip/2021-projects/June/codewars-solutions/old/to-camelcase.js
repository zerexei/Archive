// camel case
function camelCase(subject) {
  return subject
    .toLowerCase()
    .replace(/-(\w)/g, (match, char) => char.toUpperCase());
}
