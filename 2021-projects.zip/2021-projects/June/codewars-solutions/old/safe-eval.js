function saferEval(
  el,
  expression,
  dataContext,
  additionalHelperVariables = {}
) {
  return tryCatch(
    () => {
      if (typeof expression === "function") {
        return expression.call(dataContext);
      }

      return new Function(
        ["$data", ...Object.keys(additionalHelperVariables)],
        `var __alpine_result; with($data) { __alpine_result = ${expression} }; return __alpine_result`
      )(dataContext, ...Object.values(additionalHelperVariables));
    },
    {
      el,
      expression,
    }
  );
}
