// best
function pigIt(str) {
  return str.replace(/(\w)(\w*)(\s|$)/g, "$2$1ay$3");
}

// my solution
function pigIt(str) {
  //Code here
  return (
    str.split(" ") // string to words
      .map((w) => {
        // check if a special character
        if (w.match(/[^\w+]/)) {
          return w;
        }
        // word to letters
        let letters = w.split("");
        // get first letter
        const firstLetter = letters.shift();
        // append first letter
        letters.push(firstLetter);
        // concat letters then add "ay"
        return letters.join("") + "ay";
      })
      // concat with space then return
      .join(" ")
  );
}
