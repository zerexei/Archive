// best
countBits = (n) => n.toString(2).split("0").join("").length;

// my solution
var countBits = function (n) {
  return n
    // convert to base 2 number
    .toString(2)
    // convert to array
    .split("")
    // remove all 0's
    .filter((x) => x === "1")
    // count all 1's
    .length;
};
