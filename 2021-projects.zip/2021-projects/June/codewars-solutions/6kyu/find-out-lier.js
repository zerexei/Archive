function findOutlier(integers){
  //your code here
  const even = integers.filter(i => i % 2 === 0);
  const odd = integers.filter(i => i % 2 !== 0);
  return even.length > 1 ? odd[0] : even[0];
}