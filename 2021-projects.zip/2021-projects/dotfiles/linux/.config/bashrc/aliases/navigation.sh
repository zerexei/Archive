#!/bin/bash

# NAVIGRATION
alias ..='cd ..'
alias ...='cd ../../'
alias ....='cd ../../../'

alias home='cd ~'

alias proj='cd ~/projects'
alias repo='cd ~/projects/repo'
alias fork='cd ~/projects/forked'
