import { useEffect, useState } from "react";
import { RefreshIcon, CheckIcon, XIcon } from "@heroicons/react/solid";

const IsPrime = () => {
  const [prime, setPrime] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [points, setPoints] = useState(0);

  // https://stackoverflow.com/questions/3746725/how-to-create-an-array-containing-1-n
  const numbers: number[] = Array.from({ length: 100 }, (_, i) => i + 1);

  useEffect(() => {
    generatePrime();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function generatePrime() {
    const randomNumber: number =
      numbers[Math.floor(Math.random() * numbers.length)];
    setPrime(randomNumber);
  }

  function checkIfPrime(answer: boolean) {
    if (answer !== isPrime(prime)) {
      setGameOver(true);
      return;
    }

    setPoints(points + 100);
    generatePrime();
  }

  function restart() {
    setGameOver(false);
    setPoints(0);
    generatePrime();
  }

  if (gameOver) {
    return (
      <div className="text-center">
        <p className="text-xl font-bold">Score</p>
        <p className="mb-6 text-9xl font-bolder text-green-400">{points}</p>
        <p className="mb-6 text-4xl fold-bold text-red-400">Game Over!</p>
        <button
          onClick={restart}
          className="inline-flex items-center gap-1 py-2 px-3 text-white bg-blue-500 rounded"
        >
          <span>
            <RefreshIcon className="w-5 h-5" />
          </span>
          Restart
        </button>
      </div>
    );
  }

  return (
    <div className="mt-12">
      {/* DESCRIPTION */}
      <p className="mb-6 text-center tracking-wide text-gray-700">
        Determine whether the number is a prime number or not.
      </p>

      {/* INDICATOR */}
      <div className="mb-6 text-center">
        <p className="text-xl">Points: {points}</p>
        <p className="text-4xl font-bold text-red-400">Is prime?</p>
        <p className="mb-6 text-9xl font-bolder">{prime}</p>
      </div>

      {/* CONTROLS */}
      <div className="flex justify-center items-center gap-5 mb-6">
        <button
          onClick={() => checkIfPrime(true)}
          className="flex items-center gap-1 py-2 px-3 text-white bg-green-500 rounded"
        >
          <span>
            <CheckIcon className="w-5 h-5" />
          </span>
          Prime
        </button>
        <button
          onClick={restart}
          className="flex items-center gap-1 py-2 px-3 text-white bg-blue-500 rounded"
        >
          <span>
            <RefreshIcon className="w-5 h-5" />
          </span>
          Restart
        </button>
        <button
          onClick={() => checkIfPrime(false)}
          className="flex items-center gap-1 py-2 px-3 text-white bg-red-500 rounded"
        >
          <span>
            <XIcon className="w-5 h-5" />
          </span>
          Not Prime
        </button>
      </div>
    </div>
  );
};

// https://flexiple.com/isprime-javascript/
function isPrime(n: number) {
  if (isNaN(n) || !isFinite(n) || n % 1 || n < 2) return false;
  if (n === leastFactor(n)) return true;
  return false;
}

function leastFactor(n: number) {
  if (isNaN(n) || !isFinite(n)) return NaN;
  if (n === 0) return 0;
  if (n % 1 || n * n < 2) return 1;
  if (n % 2 === 0) return 2;
  if (n % 3 === 0) return 3;
  if (n % 5 === 0) return 5;
  var m = Math.sqrt(n);
  for (var i = 7; i <= m; i += 30) {
    if (n % i === 0) return i;
    if (n % (i + 4) === 0) return i + 4;
    if (n % (i + 6) === 0) return i + 6;
    if (n % (i + 10) === 0) return i + 10;
    if (n % (i + 12) === 0) return i + 12;
    if (n % (i + 16) === 0) return i + 16;
    if (n % (i + 22) === 0) return i + 22;
    if (n % (i + 24) === 0) return i + 24;
  }
  return n;
}

export default IsPrime;
