import { NavLink } from "react-router-dom";

type NavbarLinkProps = {
  url: string;
  label: string;
};

const NavbarLink = ({ url, label }: NavbarLinkProps) => {
  return (
    <NavLink
      exact
      to={url}
      activeClassName="text-red-400"
      className="p-2 hover:bg-red-100 hover:text-red-400"
    >
      {label}
    </NavLink>
  );
};

export default NavbarLink;
