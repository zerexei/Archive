import { useEffect, useState } from "react";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";

const AmIClear = () => {
  const [userIstalking, setUserIsTalking] = useState(false);
  const [result, setResult] = useState("");
  const { transcript, resetTranscript, listening, finalTranscript } =
    useSpeechRecognition();

  const sentence = "the quick brown fox jumped over the lazy dog";

  useEffect(() => {
    resetTranscript();

    if (userIstalking) {
      const result = checkAnswer(finalTranscript);
      setResult(result);
    }

    setUserIsTalking(false);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finalTranscript]);

  if (!SpeechRecognition.browserSupportsSpeechRecognition()) {
    return <p>Browser does not support speech recognition</p>;
  }

  /**
   * Start listening
   *
   * TODO: find a way to auto stop listening after a few seconds
   */
  const handleListing = () => {
    setUserIsTalking(true);
    SpeechRecognition.startListening({
      continuous: true,
    });
  };

  /**
   * Stop listening
   */
  const handleStop = () => {
    SpeechRecognition.stopListening();
  };

  /**
   * Stop listening and reset transcript value
   */
  const handleReset = () => {
    handleStop();
    resetTranscript();
  };

  function checkAnswer(answer: string): string {
    return answer === sentence ? "Correct" : "Wrong";
  }

  return (
    <div>
      <p className="mb-6">
        press "Start" to start talking, press "Stop" to stop talking and press
        "Reset" to reset your answer.
      </p>
      <p className="text-xl font-bold">Status: {result}</p>
      <p>
        Word to speak:
        <b> the quick brown fox jumped over the lazy dog</b>
      </p>
      <p>Microphone status: {listening ? "on" : "off"}</p>
      <div className="flex gap-5">
        <button
          onClick={handleListing}
          className="py-2 px-4 border border-black"
        >
          Start
        </button>
        <button 
        onClick={handleReset} 
        className="py-2 px-4 border border-black"
        >
          Reset
        </button>
        <button 
        onClick={handleStop} 
        className="py-2 px-4 border border-black"
        >
          Stop
        </button>
      </div>
      <p>{transcript}</p>
    </div>
  );
};

export default AmIClear;
