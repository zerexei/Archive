import NavLink from "./NavLink";

const NavBar = () => {
  return (
    <nav className="flex gap-8 text-sm">
      <NavLink url="#a" label="Home" />
      <NavLink url="#a" label="Profile" />
      <NavLink url="#a" label="Book list" />
      <NavLink url="#a" label="Browse" />
      <NavLink url="#a" label="Forum" />
    </nav>
  );
};

export default NavBar;
