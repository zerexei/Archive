import { ChevronDownIcon, SearchIcon } from "@heroicons/react/solid";

export const AccountSetting = () => {
  return (
    <div className="flex items-center gap-2 cursor-pointer">
      <SearchIcon className="w-6 h-6 hover:text-gray-200" />

      {/* USER AVATAR */}
      <p className="flex items-center">
        <span className="p-5 bg-red-300"></span>

        <ChevronDownIcon className="w-5 h-5 hover:text-gray-200" />
      </p>
    </div>
  );
};
