import { ChevronDownIcon } from "@heroicons/react/solid";

type DropDownFieldProps = {
  label: string;
  placeholder?: string;
};

const DropDownField = ({ label, placeholder = "Any" }: DropDownFieldProps) => {
  return (
    <div>
      {/* LABEL */}
      <h2 className="mb-2 text-sm">{label}</h2>

      {/* FIELD */}
      <div className="flex items-center gap-2 p-2 bg-gray-800 rounded">
        <input
          type="text"
          placeholder={placeholder}
          className="text-sm bg-transparent outline-none"
        />
        <ChevronDownIcon className="h-5 w-5 text-gray-500 cursor-pointer" />
      </div>
    </div>
  );
};

export default DropDownField;
