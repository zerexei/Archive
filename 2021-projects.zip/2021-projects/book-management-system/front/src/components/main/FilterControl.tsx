import DropDownField from "./filter-controls/DropDownField";
import SearchField from "./filter-controls/SearchField";

const FilterControl = () => {
  return (
    <section className="flex gap-5 mb-12">
      <SearchField />
      <DropDownField label="Genres" />
      <DropDownField label="Year" />
      <DropDownField label="Season" />
      <DropDownField label="Format" />
    </section>
  );
};

export default FilterControl;
