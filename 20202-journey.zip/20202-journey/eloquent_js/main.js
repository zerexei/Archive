// Get the index of the target value
function _index_of_value(list, target) {
  for (let i = 0; i < list.length; i++) {
    if (list[i] === target) return i;
  }

  return "Value does not exists";
}

function _looping_a_triangle(limit) {
  for (let i = 1; i <= limit; i++) {
    console.log("#".repeat(i));
  }
}

function _fizzbuzz(limit) {
  for (let i = 1; i <= limit; i++) {
    if (i % 3 == 0 && i % 5 == 0) {
      console.log("FizzBuzz");
    } else if (i % 3 == 0) {
      console.log("Fizz");
    } else if (i % 5 == 0) {
      console.log("Buzz");
    } else {
      console.log(i);
    }
  }
}

function _chessboard(h = 8, w = 8) {
  for (let i = 0; i < h; i++) {
    let str = "";
    if (i % 2) {
      for (let j = 0; j < w; j++) {
        str += j % 2 ? "#" : " ";
      }
    } else {
      for (let j = 0; j < w; j++) {
        str += j % 2 ? " " : "#";
      }
    }
    console.log(str);
  }
}

function _min(a, b) {
  return a < b ? a : b;
}

function _oddOrEven(n) {
  if (n < 0) return "Non negative integer only";
  if (n == 0) return "Even";
  if (n == 1) return "Odd";
  return _oddOrEven(n - 2);
}

function _countBs(str, target = "B") {
  let count = 0;
  for (let i = 0; i < str.length; i++) {
    if (str[i] == target) count++;
  }
  return count;
}

// a queue example (FIFO)
class _TodoList {
  #todos = [];

  // add a task
  remember(task) {
    this.#todos.push(task);
  }

  // add a task to the start of array
  rememberUrgently(task) {
    return this.#todos.unshift(task);
  }

  // get first task
  getTask() {
    return this.#todos.shift();
  }
}

// remove a value from array
function _removeFromArray(array, index) {
  return array.slice(0, index).concat(array.slice(index + 1));
}

// get the max number from the given arguments
function _max(...numbers) {
  let result = -Infinity; // lower than any negative number
  for (let number of numbers) {
    if (number > result) result = number;
  }
  return result;
}

function _range(start, end, step = 1) {
  let counter = [];
  for (let i = start; i <= end; i += step) {
    counter.push(i);
  }
  return counter;
}

function _sum(numbers) {
  let result = 0;
  for (let number of numbers) {
    result += number;
  }
  return result;
}

function _reverse(list) {
  let reversed_list = [];
  for (let i = 0; i < list.length; i++) {
    reversed_list.unshift(list[i]);
  }
  return reversed_list;
}

function _reverseArrayInPlace(list) {
  const list_len = list.length;
  const half = Math.floor(list_len / 2);

  for (let i = 0; i < half; i++) {
    let temp = list[i];
    list[i] = list[list_len - i - 1];
    list[list_len - i - 1] = temp;
  }
  return list;
}

function _arrayToList(items) {
  let list = {};
  let current = null;

  for (item of items) {
    if (current == null) {
      list = { value: item, rest: null };
      current = list;
      continue;
    }
    current.rest = { value: item, rest: null };
    current = current.rest;
  }
  return list;
}

function _listToArray(list) {
  let result = [];
  let current = list;
  while (current) {
    result.push(current.value);
    current = current.rest;
  }
  return result;
}

function _prepend(value, rest = null) {
  return { value, rest };
}

function _nth(list, index) {
  if (index == 0) return list.value;
  return _nth(list.rest, index - 1);
}

function _deepEqual(a, b) {
  if (a === b) return true;

  if (a == null || typeof a != "object" || b == null || typeof b != "object") {
    return false;
  }

  let keysA = Object.keys(a);
  let keysB = Object.keys(b);

  if (keysA.length != keysB.length) return false;

  for (let key of keysA) {
    if (!keysB.includes(key) || !_deepEqual(a[key], b[key])) {
      return false;
    }
  }

  return true;
}

function _array_filter(array, test) {
  let passed = [];
  for (let item of array) {
    if (test(item)) passed.push(item);
  }
  return passed;
}

function _array_map(array, transform) {
  let mapped = [];
  for (let item of array) {
    mapped.push(transform(item));
  }
  return mapped;
}

function _array_reduce(array, combine, start) {
  let current = start;
  for (let item of array) {
    current = combine(current, item);
  }
  return current;
}

function _flatten(array) {
  return array.reduce((prev, curr) => prev.concat(curr), []);
}

function _wierd_loop(value, test, update, action) {
  if (!test(value)) return;
  action(value);
  return _wierd_loop(update(value), test, update, action);
}

function _every(array, test) {
  for (let item of array) {
    if (!test(item)) return false;
  }
  return true;
}

// call using the prototy call method
function _normalize() {
  console.log(this.coords.map((n) => n / this.length));
}

// let _map1 = new Map();
// _map1.set("a", "One");
// _map1.set("b", "two");
// _map1.set("c", "three");
// console.log({
//   "a key exists": _map1.has("a"),
//   a: _map1.get("a"),
//   size: _map1.size,
//   "b key is deleted": _map1.delete("b"),
//   "size after delete": _map1.size,
// });

class _Vec {
  x = null;
  y = null;

  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  plus(vec) {
    let sum_of_x = this.x + vec.x;
    let sum_of_y = this.y + vec.y;
    return new _Vec(sum_of_x, sum_of_y);
  }

  minus(vec) {
    let sum_of_x = this.x - vec.x;
    let sum_of_y = this.y - vec.y;
    return new _Vec(sum_of_x, sum_of_y);
  }

  get length() {
    return Math.sqrt(this.x ** 2 + this.y ** 2);
  }
}

class _Group {
  constructor() {
    this.group = [];
  }

  static from(list) {
    let obj = new _Group();
    for (let item of list) {
      obj.add(item);
    }
    return obj;
  }

  add(item) {
    this.group.push(item);
  }

  delete(item) {
    let i = this.group.indexOf(item);
    return this.group.splice(i, 1);
  }

  has(item) {
    return this.group.includes(item);
  }

  [Symbol.iterator]() {
    return new _GroupIterator(this);
  }
}

class _GroupIterator {
  constructor(obj) {
    this.i = 0;
    this.group = obj.group;
  }

  next() {
    if (this.i == this.group.length) return { done: true };

    let value = this.group[this.i];
    this.i++;
    return { value, done: false };
  }
}

class _MultiplicatorUnitFailure extends Error {}

function _primitiveMultiply(a, b) {
  if (Math.random() < 0.2) {
    return a * b;
  } else {
    throw new _MultiplicatorUnitFailure("Klunk");
  }
}

function _reliableMultiply(a, b) {
  try {
    return _primitiveMultiply(a, b);
  } catch (e) {
    return _reliableMultiply(a, b);
  }
}