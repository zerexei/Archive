## Algorithm
> a set of steps or instructions for completing a task.

## Complexity
- time complexity
- space complexity


factorial
n! = (n) x (n-1) x (n-2) ... x (1) = n