/**
* Time: O(n^2)
 */
function selection_sort(list) {
    // get the list length
    const list_len = list.length

    // loop through the list
    for (let i = 0; i < list_len; i++) {

        // set the minimum value index
        let min_index = i

        // loop through the remaining items on the list
        for (let j = i + 1; j < list_len; j++) {

            // compare the min value with the remaining item
            if (list[min_index] > list[j]) {

                // set the next value as min
                min_index = j
            }
        }

        // min_index !== i ? swap : continue
        if (min_index !== i) {

            // SWAPPED
            const temp = list[i]
            list[i] = list[min_index]
            list[min_index] = temp
        }
    }

    // return the list
    return list
}

const list = [5, 4, 3, 2, 1]

const x = selection_sort(list)


console.log(x);