// time complexity: O(n^2)
// space complexity: O(1)
function bubble_sort(list) {
    // set an indicator if swapped
    let swapped = false;

    do {
        // reset the swapped indicator
        swapped = false;

        // loop through list
        for (let i = 1; i < list.length; i++) {
            // set left and right value to compare
            let left = list[i - 1];
            let right = list[i]

            // compare the left and right value
            if (left > right) {
                // swap the left and right value from list
                [list[i - 1], list[i]] = [right, left];
                // set the swapped indicator to true
                swapped = true
            }
        }
    // loop again if swapped indicator is true
    } while (swapped);

    // return the sorted list
    return list;
}

























// function linear_search(list, target) {
//     for (index is 0; index is less than list_length; increase index) {
//         if list[index] is equals to target
//             return index
//     }

//     if not found return false
// }



// function linear_search(list, target) {
//     // return list.indexOf(target);

//     for (let i = 0; i < list.length; i++) {
//         if (list[i] == target) return i
//     }

//     return false
// }

// const x = linear_search([1,2,3,4,5], 9)
// console.log(x);


// function binary_search(list, target) {
//     let first = 0
//     let last = list_length - 1

//     while first is less than or equals to last
//         let midpoint = (first + last) / 2 THEN round down

//         if list[midpoint] == target
//             return midpoint
//         else if list[midpoint] is less than target
//             first = midpoint + 1
//         else
//             last = midpoint - 1

//     return false




// function binary_search(list, target) {
//     let first = 0
//     let last = list.length - 1

//     while (first <= last) {
//         let midpoint = Math.floor((first + last) / 2)

//         if (list[midpoint] == target) return midpoint

//         if (list[midpoint] < target) {
//             first = midpoint + 1
//         } else {
//             last = midpoint - 1
//         }
//     }

//     return false
// }


// let x = binary_search([1,2,3,4,5], 5)
// console.log(x);













































// function linear_search(list, target) {
//     for (let i=0;i<list.length;i++ ) {
//         if (list[i] == target) {
//             return i
//         }
//     }

//     return false
// }

// const x = linear_search([1,2,3,4,5], 5)
// console.log(x);


// function binary_search(list, target) {
//     let first = 0
//     let last = list.length - 1

//     while (first <= last) {
//         let midpoint = Math.floor((first + last) / 2)

//         if (list[midpoint] == target) {
//             return midpoint;
//         }

//         if (list[midpoint] < target) {
//             first = midpoint + 1
//         } else {
//             last = midpoint - 1
//         }
//     }

//     return false
// }

// const x = binary_search([1,2,3,4,5], 5)
// console.log(x);


// // cant return index since the list is being sliced
// function recursive_binary_search(list, target) {
//     if (list.length == 0) return false

//     let midpoint = Math.floor(list.length / 2)

//     if (list[midpoint] == target) return true

//     if (list[midpoint] < target) {
//         return recursive_binary_search(list.slice(midpoint + 1), target)
//     } else {
//         return recursive_binary_search(list.slice(0, midpoint), target)
//     }
// }

// const x = recursive_binary_search([1,2,3,4,5], 5)
// console.log(x);


// function merge_sort(list) {
//     if (list.length <= 1) return list

//     let [left_half, right_half] = slice(list)

//     let left = merge_sort(left_half)
//     let right = merge_sort(right_half)

//     return merge(left, right)
// }

// function slice(list) {
//     const midpoint = Math.floor(list.length / 2)
//     const left = list.slice(0, midpoint)
//     const right = list.slice(midpoint)
//     console.log(`midpoint: ${midpoint} : left: [${left}] : right: [${right}]`);
//     return [left, right]
// }

// function merge(right, left) {
//     console.log(`unsorted: [${right}, ${left}]`);
//     let list = []

//     while (left.length > 0 && right.length > 0) {
//         if (left[0] < right[0]) {
//             list.push(left[0])
//             left = left.slice(1)
//         } else {
//             list.push(right[0])
//             right = right.slice(1)
//         }
//     }

//     while (left.length > 0) {
//         list.push(left[0])
//         left = left.slice(1)

//     }

//     while (right.length > 0) {
//         list.push(right[0])
//         right = right.slice(1)

//     }

//     console.log(`sorted: ${list}`);
//     console.log(" ");
//     console.log(" ");
//     console.log(" ");
//     return list
// }


// unsorted_list = [1,2,3,4,5,6,7,8,9]
// sorted = merge_sort(unsorted_list)
// console.log(sorted)