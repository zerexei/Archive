function toArray(list) {
    let current = list.head
    let output = []

    while (current) {
        output.push(current.data)
        current = current.next
    }

    return output
}


class Node {
    data = null
    next = null // reference

    constructor(data, next_node = null) {
        this.data = data
        this.next = next_node
    }
}

class LinkedList {
    head = null

    /**
     * Add a new Node to list
     * time: O(1)
     */
    add(data) {
        const node = new Node(data, this.head)
        this.head = node
        return 1
    }

    /**
     * Insert a new Node at a specific index to list 
     * time: O(n)
     */
    insert(data, index = 0) {
        if (index > this.size()) {
            console.log("Index out of range");
            return 0
        }

        if (index === 0) {
            this.add(data)
            return 1
        }


        const new_node = new Node(data)
        let current = this.head
        let position = index

        while (position > 1) {
            current = current.next
            position = position - 1
        }

        if (index === this.size()) {
            current.next = new_node
            return 1
        }

        const prev_node = current
        const next_node = current.next

        prev_node.next = new_node // before new node
        new_node.next = next_node // after new node

        return 1
    }


    /**
     * Remove a node at a specific index from list
     * time: O(n)
     */
    remove(key) {
        let current = this.head
        let prev_node = null

        while (current) {
            if (current.data == key && current == this.head) {
                this.head = current.next
                return 1
            }

            if (current.data != key) {
                prev_node = current
                current = current.next

            } else {
                prev_node.next = current.next
                return 1
            }
        }

        console.log("Key does not exists");
        return 0
    }


    /**
     * return the Node at a current index
     * time: O(n)
     */
    node_at_index(index) {
        if (index >= this.size()) return null

        if (index == 0) return this.head

        let count = 0
        let current = this.head

        while (count < index) {
            current = current.next
            count = count + 1
        }

        return current
    }

    /**
     * Remove a Node at a specific index from list
     * time: O(n)
     */
    remove_at_index(index) {
        if (index >= this.size()) {
            console.log("Index out of range");
            return 0
        }

        if (index === 0) {
            this.head = this.head.next
            return 1
        }

        let count = 1
        let current = this.head

        while (count < index) {
            current = current.next
            count = count + 1
        }


        current.next = current.next.next
        return 1
    }

    /**
     * Return the size of the list
     * time: O(n)
     */
    size() {
        let current = this.head
        let count = 0

        while (current) {
            count = count + 1
            current = current.next
        }

        return count
    }

    /**
     * Check if the list is empty
     */
    is_empty() {
        return this.head == null
    }
}


// create a list
const list = new LinkedList()

list.add(1)
list.add(2)
list.add(3)
list.add(4)
list.add(5)

// const out = list.insert(6, 0)
// const out = list.insert(7, 1)
// const out = list.insert(8, 2)
// const out = list.insert(9, 4)
// const out = list.insert(10, 5)
// const out = list.insert(11, 6)

// const out = list.remove(1)
// const out = list.remove(4)
// const out = list.remove(3)
// const out = list.remove(5)
// const out = list.remove(6)

// const out = list.remove_at_index(0)
// const out = list.remove_at_index(1)
// const out = list.remove_at_index(2)
// const out = list.remove_at_index(3)
// const out = list.remove_at_index(4)
// const out = list.remove_at_index(5)

// const out = list.node_at_index(0)
// const out = list.node_at_index(1)
// const out = list.node_at_index(2)
// const out = list.node_at_index(4)
// const out = list.node_at_index(5)

// console.log(toArray(list))
// console.log(out);








function linked_list_merge_sort(list) {
    if (list.size() == 1 || list.head == null) {
        return list
    }

    let [left_half, right_half] = split(list)
    let left = linked_list_merge_sort(left_half)
    let right = linked_list_merge_sort(right_half)

    return merge(left, right)
}

function split(list) {
    if (list == null || list.head == null) {
        return [list, null]
    }

    // get the size of linked list
    let size = list.size()
    let midpoint = Math.floor(size / 2)


    let mid_node = list.node_at_index(midpoint - 1)

    let right = new LinkedList()
    right.head = mid_node.next

    // unlinked the half of linked list
    mid_node.next = null

    // return the left and right half of linked list
    return [list, right]
}

function merge(left, right) {
    let merged = new LinkedList()
    merged.add(0)

    let current = merged.head
    let left_head = left.head
    let right_head = right.head

    while (left_head || right_head) {
        if (left_head == null) {
            current.next = right_head
            right_head = right_head.next

        } else if (right_head == null) {
            current.next = left_head
            left_head = left_head.next

        } else {
            left_data = left_head.data
            right_data = right_head.data

            if (left_data < right_data) {
                current.next = left_head
                left_head = left_head.next
            } else {
                current.next = right_head
                right_head = right_head.next
            }

        }

        current = current.next
    }

    head = merged.head.next
    merged.head = head
    return merged
}


// const list = new LinkedList()
// list.add(6)
// list.add(4)
// list.add(1)
// list.add(5)
// list.add(3)
// list.add(2)

// let sorted = linked_list_merge_sort(list)
// console.log(sorted)

// list.remove(3)
// console.log(list)