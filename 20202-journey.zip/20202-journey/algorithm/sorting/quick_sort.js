function quick_sort(list) {
  // recursion stopper
  if (list.length <= 1) {
    return list;
  }

  // get pivot
  const pivot = list[list.length - 1];

  // set left and right list placeholder
  const left = [];
  const right = [];

  // loop through list
  for (let i = 0; i < list.length - 1; i++) {
    // sort greater and less than pivot values
    if (list[i] < pivot) {
      left.push(list[i]);
    } else {
      right.push(list[i]);
    }
  }

  return [...quick_sort(left), pivot, ...quick_sort(right)];
}

const a = quick_sort([3, 2, 1]);
const b = quick_sort([9, 8, 7, 6, 5, 4, 3, 2, 1]);
const c = quick_sort([91, 28, 73, 46, 55, 64, 37, 82, 19]);
console.log("Quick Sort");
console.log(a);
console.log(b);
console.log(c);
