function selection_sort(list) {
  // loop through the list
  for (let i = 0; i < list.length; i++) {
    // set the index of min
    let index_of_min = i;

    // loop through remaining list
    for (let j = i + 1; j < list.length; j++) {
      // compare
      if (list[i] > list[j]) {
        // update new min
        index_of_min = j;
      }
    }

    // check if the index of min is not equals to current index
    if (index_of_min != i) {
      // swap
      let temp = list[i];
      list[i] = list[index_of_min];
      list[index_of_min] = temp;
    }
  }

  // return sorted list
  return list;
}

const a = selection_sort([3, 2, 1]);
const b = selection_sort([9, 8, 7, 6, 5, 4, 3, 2, 1]);
const c = selection_sort([91, 28, 73, 46, 55, 64, 37, 82, 19]);
console.table({ label: "selection sort", test1: a, test2: b, test3: c });
