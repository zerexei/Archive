function insertion_sort(list) {
  // loop through list
  for (let i = 1; i < list.length; i++) {
    // set the current value to sort
    let current = list[i];
    // while loop stopper
    let j = i - 1;

    // start insertion sort
    while (j >= 0 && current < list[j]) {
      // move values
      list[j + 1] = list[j];
      // decrease j value to loop from right to left
      j--;
    }

    // insert correct position
    list[j + 1] = current;
  }

  return list;
}

const a = insertion_sort([3, 2, 1]);
const b = insertion_sort([9, 8, 7, 6, 5, 4, 3, 2, 1]);
const c = insertion_sort([91, 28, 73, 46, 55, 64, 37, 82, 19]);
console.dir(a, b, c);
