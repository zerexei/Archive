function merge_sort(list) {
  // check if list length is less than 2
  if (list.length < 2) return list;

  // call slice method to get the 2 half array
  let [left_half, right_half] = slice(list);

  // get left and right value
  let left = merge_sort(left_half);
  let right = merge_sort(right_half);

  // call merge method to merge 2 value/array
  return merge(left, right);
}

// slice an array to half and return the first and second half of array
function slice(list) {
  // get midpoint of array
  const midpoint = Math.floor(list.length / 2);
  // slice array to first half
  const left = list.slice(0, midpoint);
  // slice array to second half
  const right = list.slice(midpoint);

  // return sliced array
  return [left, right];
}

// merge 2 arrays
function merge(right, left) {
  // set set sorted list
  let list = [];

  // loop through list
  while (left.length > 0 && right.length > 0) {
    // compare left and right value
    if (left[0] < right[0]) {
      // push to sorted list
      list.push(left[0]);
      // shift list
      left = left.slice(1);
    } else {
      // push to sorted list
      list.push(right[0]);
      // shift list
      right = right.slice(1);
    }
  }

  // loop through remaining list
  while (left.length > 0) {
    list.push(left[0]);
    left = left.slice(1);
  }

  // loop through remaining list
  while (right.length > 0) {
    list.push(right[0]);
    right = right.slice(1);
  }

  // return sorted list
  return list;
}

const a = merge_sort([3, 2, 1]);
const b = merge_sort([9, 8, 7, 6, 5, 4, 3, 2, 1]);
const c = merge_sort([91, 28, 73, 46, 55, 64, 37, 82, 19]);

console.log("Merge Sort");
console.log(a);
console.log(b);
console.log(c);
