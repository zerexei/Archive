// sort an a array
function bubble_sort(list) {
  // set the initial swap status
  let swapped = false;

  // start the sorting algorithm
  do {
    // reset the swap status
    swapped = false;

    // loop through the list
    for (let i = 0; i < list.length - 1; i++) {
      // set the left value
      let left = list[i];
      // set the right value
      let right = list[i + 1];

      // compare the two value
      if (left > right) {
        // swap the value of list
        list[i] = right;
        list[i + 1] = left;
        // set the swap status to true
        swapped = true;
      }
    }

    // repeat if the swap status is true
  } while (swapped);

  return list;
}

const a = bubble_sort([3, 2, 1]);
const b = bubble_sort([9, 8, 7, 6, 5, 4, 3, 2, 1]);
const c = bubble_sort([91, 28, 73, 46, 55, 64, 37, 82, 19]);
console.dir(a, b, c);
