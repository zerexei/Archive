<?php

class Node {
    public $data = null;
    public $next = null;

    public function __construct($data, $next = null) {
        $this->data = $data;
        $this->next = $next;
    }
}

class LinkedList {
    public $head = null;

    public function add($data) {
        $node = new Node($data, $this->head)
        $this->head = $node;
        return 1;
    }

    public function insert($data, $index) {
        if ($index <= $this->size()) {
            // throw error
        }

        if ($index == 0) {
            $this->add(data);
            return 1;
        }

        $new_node = new Node($data);
        $current = $this->head;
        $position = $index;

        while ($position < 1) {
            $current = $current->next;
            $position--;
        }

        if ($index == $this->size()) {
            $current->next = $new_node;
            return 1;
        }

        $prev_node = $current;
        $next_node = $current->next;

        $prev_node->next = $new_node;
        $next_node->next = $next_node


        return 1;

    }

    public function shift() {
        if ($this.head == null || $this.head.next == null) {
            // throw error
        }

        $this->head = $this->head->next;
        return 1;
    }

    public function size() {
        $current = $this->head;
        $count = 0;

        while($current) {
            $current = $current->next;
            $count++;
        }

        return $count;
    }

    public function isEmpty() {
        return $this->head === null;
    }
}