# Computer Science

## Analytical Engine
- general purpose computer
- could be used for more than one particular computing
- could be given data and run operations in sequece
- had memory and primitive printer

## ENIAC
- Electronic
- Numerical
- Integrator
- And
- Calculator

## OPCODE or operational code
- also known as instraction machine code
- the portion of a machine language instruction that specifies the operation to be perfomed

## OS
- batch processing
- I/O
- virtual memory
- time-sharing
- 

> rewatched till OS (note all highlighted words)

## memory & storage
- stored program computer
- sequential / cyclic-access memory
- random access memory
  - delay line memory
  - magnetostrictive delay lines
  - magnetic core memory
- magnetic drum memory
- floppy disk
- optical storage
- compact disk
- solid state drive

## files & filesystem
- file format
  - jpeg
  - mp3
  - txt
- ASCII -> character encoding standard
- wave file / wav -> for audio
- metadata -> data about data
- amplitude
- bitmap / bmp
  - pixels
- flat filesystem 
- fragmentation
- defragmentation

## compression
- run-length encoding
- lossless compresion
- huffman code
- lossy compression techniques
- lossy audio compression
- perceptual coding -> comes from a field of study called psychophysics
- temporal redundancy
- inter-frame similariteis

## screen & 2d graphics
- vector scanning
- raster scanning
- liquid crystal display
- read only memory / ROM
- screen buffer
- frame buffer
- video ram / vram

## GUI
- desktop metaphor
- windows icon menu pointer (wimp) interface 
- what you see is what you get (wysiwyg)

## 3d graphics
- 3d protection
- wireframe rendering
- orthographic projection
- perspective projection
- scanline rendering
- anti aliasing
- occlusion
- painter's algorithm
- z-buffering
- shading
  - flat shading
  - gouraud shading
  - phong shading
- texture
  - texture mapping
- graphics processing using (GPU)

## network
- sneakernet
- local area networks (LAN)
- ethernet
- media access control (MAC) address
- carrier sense multiple access (CSMA) -> the "carrier" is any shared transmission medium
  - bandwidth
  - collision -> both write data at the same time
- exponential backoff
- collision domain
- routing
- circuit switching
- message switching
- hop count
- hop limit
- packets
  - contains destination address on the network
- internet protocol (IP) / Address
- TCP / IP
- packet switching
- Advance Research Project Agency (ARPA) net
- internet of things (IoT)

## internet
- wide area networl (WAN)
- internet service provider (ISP)
- internet protocol (IP)
- user datagram protocol (UDP)
- transmission control protocol (TCP)
- domain name system (DNS)
- layer of open system interconnection (OSI) model
  - application layer
  - presentation layer
  - session layer
  - transport layer
  - network layer
  - data link layer
  - physical layer

## www
- hyperlink
- hypertext
- uniform resource locator (URL)
- hypertext transfer protocol (HTTP)
- http status
- net neutrality

## cybersecurity
- attack vector
- authentication
  - what you know (password)
  - what you have (tokens, key)
  - what you are (biometrics)
    - probabilistic
- brute force attack
- access control
- permission
  - read
  - write
  - execute
- access control lists (ACL)
- bell-lapadula model
- chineses wall model
- biba model
- malware
  - security kernel
  - trusted computing base
- independent verification  & validation
- virtual machines

## cryptography - secret writting
- cipher
  - substitution cipher
    - ceasar cipher
  - permutation cipher
  - columnar transposition cipher
- encryption
- decryption
- cryptanalyst
- data encryption standard
- advance encryption standar (AES)
  - 16 byte block
- key exchange
  - one way function
- diffie-hellman key exchange
- symmetric encryption
- asymmetric encryption

## Machine learning
- confusion matrix
- decision tree
- support vector machines
- hyperplane
- statistics
- artificial neural network
  - artificial neurons
    - input layer
    - hidden layer
    - output layer
- weak ai
- narrow ai
- strong ai
- reinforcement learning

# computer vision
- convolution
- prewitt operators
- viola-jones face detection
- convolutional neural network