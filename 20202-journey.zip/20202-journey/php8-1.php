<?php

// # PHP v8.1

//* Enums
enum TrafficLight
{
    case Go;
    case Ready;
    case Stop;
}

function getCurrentTrafficLight(TrafficLight $light): string {
    return $light->name;
}

getCurrentTrafficLight(TrafficLight::Ready);

//* Readonly property

class Publish
{
    public readonly bool $status;

    public function __construct($status)
    {
        $this->status = $status;
    }
}

$published = new Publish(true);
$published->status = false; // Cannot modify readonly property

var_dump($published);

//* New Initializer
// - Objects can now be used as default parameter values, static variables, 
// - and global constants, as well as in attribute arguments.
class Service
{
    private logger $logger;

    public function __construct(
        Logger $logger = new NullLogger()
    ) {
        $this->logger = $logger;
    }
}

// nested attributes
class User
{
    #[\Assert\All(
        new \Assert\NotNull,
        new \Assert\Length(min: 6))
    ]
    public string $name = '';
}

//* Pure intersection types
function count_it(Iterator&countable $counter) { 
    foreach ($counter as $c) { echo $c; }
}

//* Never return type
function redirect(string $uri): never {
    header(`Location:{$uri}`);
    exit();
}

// * Final class constant
class Foo
{
    final public const XX = "foo";
}

class Bar extends Foo
{
    public const XX = "bar"; // Fatal error
}

//* Explicit Octal numeral notation
0o16 === 16; // false — not confusing with explicit notation
0o16 === 14; // true
