# 20202-journey
my year 2022 journey
