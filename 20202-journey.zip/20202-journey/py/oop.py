# from file_path import ClassName

# class Car:
#     wheels = 4
#
#     def __init__(self, make, model, year, color):
#         self.make = make
#         self.model = model
#         self.year = year
#         self.color = color
#
#     def drive(self):
#         return f"The {self.model} is driving"
#
#     def stop(self):
#         pass
#
#
# car = Car("foo", "bar", "1999", "blue")
# print(car.drive())
#
# print(f"the {car.model} has {car.wheels} wheels")
# car.wheels = 2
# print(f"now it only has {car.wheels} wheels")


# INHERITANCE

# parent class
class A:
    pass

# child of class A
class B(A):
    pass

# child of class B
class C(B):
    pass