"""
    Calculating the factors of an integer
    - a number that evenly divides a larger number
"""
#
# def is_factor(a, b):
#     if b % a == 0:
#         return True
#     else:
#         return False
#
#
# print(is_factor(2, 1))


"""
    Find the factors of an integer
"""
#
#
# def factors(n):
#
#     for i in range(1, n +1):
#         if n % i == 0:
#             print(i)
#
# factors(6)


# """
#     Generate a multiplication table
# """
#
#
# def multi_table(n):
#     for i in range(11):
#         result = n * i;
#         print(f"{n} x {i} = {result}")
#
#
# num1 = input("Enter base number: ")
#
# if not num1.isnumeric():
#     print("invalid integer")
# else:
#     num1 = int(num1)
#     multi_table(num1)


# print(f"{0.12345:.3f}")


# 1 + 2 + 3 + 4 + 5 = 15
# def summation(num):
#     total = 0
#
#     for i in range(1, num + 1):
#         total = total + i
#
#     return total


# sort vs sorted vs reversed
# sort - sorts the list (mutates the list)
# sorted - returns a sorted list of the specified iterable object
# reversed - returns a reversed iterator object

# def descending_order(num):
#     return int("".join(reversed(str(num))))


# # convert string to jaden case
# def toJadenCase(string):
#     return " ".join(word.capitalize() for word in string.split())

def find_next_square(sq):
    root = math.sqrt(sq)
    return (root + 1) ** 2 if root.is_integer() else -1


