import math

# variables

# name = "John"
# age = 15
# print("your name is " + name + " and your age is " + str(age))

# first_name = "John"
# last_name = "Doe"
# full_name = first_name + " " + last_name
# print("Your full name is " + full_name)

# one = two = three = "works"
# print(one)

# name = "Johnjane"
# print(name.find('h'))
# print(name.upper())
# print(name.isdigit())
# print(name.isalpha())
# print(name.count("j"))

# a = 1
# b = 2.0
# c = "3"
# print(type(c))
# c = int(c)
# print(type(c))

# age = input("Enter age: ")
# if not age.isdigit():
#     print("invalid input")
# else:
#     print(f"your age is {age}")

# print(math.pi)

# reversed_string = "Hello World!"
# print(reversed_string[::-1])

# sliced = "https://Hello World!.com"[7:-4]
# print(sliced)

# first = input("Enter first digit: ")
# second = input("Enter second digit: ")
# operation = input("""Calculator
# a. Addition
# b. Subtraction
# c. Multiplication
# d. Division
# """)
#
# if operation == "a":
#     result = float(first) + float(second)
#     print(f"{first} + {second}")
# elif operation == "b":
#     result = float(first) - float(second)
#     print(f"{first} - {second}")
# elif operation == "c":
#     result = float(first) * float(second)
#     print(f"{first} * {second}")
# elif operation == "d":
#     result = float(first) / float(second)
#     print(f"{first} / {second}")
# else:
#     result = "invalid"
#
# print(f"The result is {result}")


# LOGICAL OPERATOR
# print(True == True) # equality
# print( True != False) # inequality
# print(not True == False) # inverse boolean value

# age = 5
# isFoo = True
#
# if age < 13 and not isFoo:
#     print("kid")
# elif age < 21 and isFoo:
#     print("Teen")
# elif age < 31:
#     print("Adult")
# else:
#     print("old")

# check whether the string can be converted to numeric value
def is_numeric(n):
    try:
        float(n)
        return True
    except ValueError:
        return False


weight = input("Enter weight: ")
unit = input("(K)g or (L)bs: ")

if not (weight):
    print("invalid weight")
    weight = 0

weight = float(weight)

if unit.upper() == 'K':
    result = weight / 2.205
    print(f"Weight in kg: {result}")
elif unit.upper() == 'L':
    result = weight * 2.205
    print(f"Weight in lbs: {result}")
else:
    print("Invalid unit")

# numbers = [1,2,3,4,5]
# print(numbers)
# numbers.insert(0,99)
# print(numbers)
# numbers.remove(99)
# print(numbers)
# numbers.clear()
# print(numbers)

# for n in range(1, 6):
#     print(n)


# tuples

# numbers = (1,2,3,4,5)


