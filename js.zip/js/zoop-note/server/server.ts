import express from "express";
import cors from "cors";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const app = express();

app.use(cors());
app.use(express.json());

// connection refused for prisma client
app.post("/notes", async (req, res) => {
  const note = await prisma.note.create({
    data: {
      title: req.body.title,
      body: req.body?.body,
      createdAt: req.body.createdAt,
    },
  });
  res.status(201).send(note);
});

app.get("/notes", async (req, res) => {
  const notes = await prisma.note.findMany();
  res.status(200).send(notes);
});

app.put("/notes/:id", async (req, res) => {
  const note = await prisma.note.update({
    where: {
      id: Number(req.params.id),
    },
    data: {
      title: req.body.title,
      body: req.body.body,
    },
  });
  res.status(200).send(note);
});

// check prisma if it returns the deleted note
app.delete("/notes", async (req, res) => {
  const note = await prisma.note.delete({
    where: {
      title: req.body.title,
    },
  });
  res.status(204).send(note);
});

app.listen(3001, () => {
  console.log("Running...");
});
