import { useEffect, useState } from "react";

import Main from "./components/Main/Main";
import NewNote from "./components/NewNote";
import Header from "./components/header/Header";

export interface NoteProps {
  id: number;
  title: string;
  body?: string;
  createdAt: string;
}

export type ActiveNoteProps = NoteProps | null;
export type StoreNoteProps = (title: string, body?: string) => void;
export type UpdateNoteProps = (note: NoteProps) => void;
export type DeleteNoteProps = (id: number) => void;
export type ToggleShowCreateNoteFormProps = () => void;

/**
 * TODO:
 * 1. create twcss component class
 * 2. refactor
 * 3. FIX: component names
 *
 * ! NOT RESPONSIVE DESIGN
 */
function App() {
  const [notes, setNotes] = useState<NoteProps[]>([]);
  const [activeNote, setActiveNote] = useState<ActiveNoteProps>(null);
  const [isShowCreateNote, setIsShowCreateNote] = useState<boolean>(false);

  /**
   * Get all notes on page load
   */
  useEffect(() => {
    (async () => {
      const fetchedNotes = await fetch("http://127.0.0.1:3001/notes");
      setNotes(await fetchedNotes.json());
    })().catch((err) => console.error(err));
    return () => {};
  }, [notes, activeNote]);

  const changeActiveNote = (note: NoteProps) => setActiveNote(note);
  const toggleShowCreateNoteForm = () => setIsShowCreateNote(!isShowCreateNote);

  /**
   * Create a note
   */
  const storeNote: StoreNoteProps = (title, body) => {
    // prevent empty title
    if (title === "") {
      alert("Title is required.");
      return;
    }

    const createdAt = new Date().toString();
    const data = { title, body, createdAt };

    (async () => {
      await fetch("http://127.0.0.1:3001/notes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
    })();

    toggleShowCreateNoteForm();
  };

  /**
   * Update a note
   */
  const updateNote = (note: NoteProps) => {
    if (note.title === "") {
      alert("Title is required.");
      return;
    }
    (async () => {
      await fetch(`http://127.0.0.1:3001/notes/${note.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(note),
      });
    })().catch((err) => console.error(err));
    setActiveNote(note);
    alert("Note saved.");
  };

  /**
   * Delete a note
   */
  const deleteNote = (id: number) => {
    (async () => {
      await fetch("http://127.0.0.1:3001/notes", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(activeNote),
      });
    })().catch((err) => console.error(err));

    // remove active note
    setActiveNote(null);

    alert("Note deleted.");
  };

  return (
    <div className="relative p-8">
      <Header
        activeNote={activeNote}
        showCreateNote={toggleShowCreateNoteForm}
        deleteNote={deleteNote}
      />
      <Main
        notes={notes}
        activeNote={activeNote}
        setActiveNote={changeActiveNote}
        updateNote={updateNote}
      />
      <NewNote
        show={isShowCreateNote}
        closeCreateNote={toggleShowCreateNoteForm}
        storeNote={storeNote}
      />
    </div>
  );
}

export default App;
