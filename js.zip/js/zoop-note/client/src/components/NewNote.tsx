import { useRef } from "react";
import { StoreNoteProps, ToggleShowCreateNoteFormProps } from "../App";

type NewNoteProps = {
  show: boolean;
  closeCreateNote: ToggleShowCreateNoteFormProps;
  storeNote: StoreNoteProps;
};

const NewNote = ({ show, closeCreateNote, storeNote }: NewNoteProps) => {
  const titleRef = useRef<HTMLInputElement>(null);
  const bodyRef = useRef<HTMLTextAreaElement>(null);

  const createNote = () => {
    storeNote(titleRef.current?.value || "", bodyRef.current?.value || "");
    if (titleRef.current) titleRef.current.value = "";
    if (bodyRef.current) bodyRef.current.value = "";
  };

  return (
    <div
      className={`${
        show ? "flex" : "hidden"
      } fixed top-0 left-0 items-center justify-center h-full w-full bg-opacity-50 bg-gray-700`}
    >
      <div className="z-10 -mt-10 w-1/2 p-6 bg-white shadow rounded">
        <form action="/">
          {/* TITLE */}
          <div className="mb-6">
            <label
              htmlFor="title"
              className="block mb-1 text-sm font-bold text-gray-500"
            >
              Title
            </label>
            <input
              ref={titleRef}
              id="title"
              name="Title"
              type="text"
              placeholder="Title..."
              className="w-full p-2 border rounded outline-none"
            />
          </div>

          {/* BODY */}
          <div className="mb-6">
            <label
              htmlFor="body"
              className="block mb-1 text-sm font-bold text-gray-500"
            >
              body
            </label>
            <textarea
              ref={bodyRef}
              id="body"
              name="body"
              placeholder="Write a note..."
              className="w-full h-72 p-2 border rounded outline-none resize-none"
            ></textarea>
          </div>

          {/* CONTROLS */}
          <div className="flex justify-end gap-2 mb-6">
            <button
              onClick={createNote}
              type="button"
              className="py-2 px-3 text-white bg-blue-400 rounded"
            >
              Add note
            </button>

            <button
              onClick={() => closeCreateNote()}
              type="button"
              className="py-2 px-3 text-white bg-red-400 rounded"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewNote;
