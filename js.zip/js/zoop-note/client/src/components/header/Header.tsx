import { ClockIcon, DotsIcon, InfoIcon, PlusIcon, TrashIcon } from "../Icons";
import Author from "./Author";
import SearchInput from "./SearchInput";

import {
  ActiveNoteProps,
  DeleteNoteProps,
  ToggleShowCreateNoteFormProps,
} from "../../App";

type HeaderProps = {
  activeNote: ActiveNoteProps;
  deleteNote: DeleteNoteProps;
  showCreateNote: ToggleShowCreateNoteFormProps;
};

const Header = ({ activeNote, deleteNote, showCreateNote }: HeaderProps) => {
  return (
    <header className="bg-blue-100 flex gap-2 items-center w-full p-4">
      {/* search note */}
      <SearchInput />

      {/* add note */}
      <button onClick={showCreateNote} type="button">
        <PlusIcon color="blue" />
      </button>

      {/* note info? */}
      <button children={<InfoIcon color="blue" />} />

      {/* created at note? */}
      <button children={<ClockIcon color="blue" />} />

      {/* delete note */}
      {activeNote && (
        <button
          onClick={() => deleteNote(activeNote.id)}
          children={<TrashIcon color="blue" />}
        />
      )}

      {/* more options */}
      <button children={<DotsIcon color="blue" />} />

      <Author />
    </header>
  );
};

export default Header;
