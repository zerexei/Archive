// COMPONENTS

// TYPES
import { NoteProps } from "../../App";

type ActionsProps = {
  activeNote: NoteProps | null;
  deleteNote: (id: number) => void;
};

const Actions = ({ activeNote, deleteNote }: ActionsProps) => {

  return (
    <div className="flex gap-2">
    </div>
  );
};

export default Actions;
