import { SearchIcon } from "../Icons";

const SearchInput = () => {

  // // search note
  // function search(key) {
  //   const regex = new RegExp(`^${key}`,'ig')
  //   const filtered = words.filter((word) => word.match(regex))
  //   console.log(filtered);
  // }
  

  return (
    <div className="flex items-center w-1/4 p-2 border border-blue-300 rounded-full">
      <span className="mr-4">
        <SearchIcon color="blue" />
      </span>

      <input
        type="text"
        placeholder="Search a note..."
        className="flex-1 outline-none text-gray-700 bg-blue-100"
      />
    </div>
  );
};

export default SearchInput;
