const Author = () => {
  return (
    <div className="ml-auto">
      <a href="#a">sample@mail.com</a>
    </div>
  );
};

export default Author;
