import NoteArea from "./NoteArea";
import NotesList from "./NotesList";

import { ActiveNoteProps, NoteProps, UpdateNoteProps } from "../../App";

type MainProps = {
  notes: NoteProps[];
  activeNote: ActiveNoteProps;
  updateNote: UpdateNoteProps;
  setActiveNote: (note: NoteProps) => void;
};

const Main = ({ notes, activeNote, setActiveNote, updateNote }: MainProps) => {
  return (
    <main className="flex">
      <NotesList
        notes={notes}
        activeNote={activeNote}
        setActiveNote={setActiveNote}
      />
      <NoteArea activeNote={activeNote} updateNote={updateNote} />
    </main>
  );
};

export default Main;
