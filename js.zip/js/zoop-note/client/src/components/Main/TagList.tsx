// COMPONETS
import { ChevronDownIcon } from "../Icons";

const TagList = () => {
  return (
    <p className="flex py-2 px-4 text-blue-400 border-l">
      <span className="cursor-pointer">
        Tags{" "}
        <button className="focus:outline-none">
          <ChevronDownIcon color="blue" size="sm" />
        </button>
      </span>
    </p>
  );
};

export default TagList;
