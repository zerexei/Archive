// TYPES
import { NoteProps } from "../../App";

type NoteMenuSlugProps = {
  note: NoteProps;
  active?: boolean;
  setActiveNote: (note: NoteProps) => void;
};
const NoteMenuSlug = ({
  note,
  active = false,
  setActiveNote,
}: NoteMenuSlugProps) => {
  const activeCss = active ? "bg-blue-100" : "";
  const css = `p-2 px-8 cursor-pointer ${activeCss} hover:bg-blue-100`;

  return (
    <li className={css} onClick={() => setActiveNote(note)}>
      <h3>{note.title}</h3>
      <p className="text-sm text-gray-500">{note.body}</p>
    </li>
  );
};

export default NoteMenuSlug;
