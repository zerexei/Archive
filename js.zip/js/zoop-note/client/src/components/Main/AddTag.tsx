// TODO: rename component
// TODO: show save button on input change, hidden when no changes

import { ActiveNoteProps, NoteProps, UpdateNoteProps } from "../../App";

type AddTagProps = {
  activeNote: ActiveNoteProps;
  updateNote: UpdateNoteProps;
  title: string;
  body: string;
};

const AddTag = ({ activeNote, updateNote, title, body }: AddTagProps) => {
  const note: NoteProps = { id: 0, createdAt: "", ...activeNote, title, body };

  function hasChanged() {
    if (activeNote?.title !== title) return true;
    if (activeNote?.body !== body) return true;
    return false;
  }

  return (
    <div className="flex justify-between items-center py-2 px-4 border-b">
      <input
        type="text"
        placeholder="Add tag..."
        className="flex-1 outline-none"
      />

      {hasChanged() && (
        <button
          onClick={() => updateNote(note)}
          type="button"
          className="py-2 px-6 text-gray-900 bg-blue-300 rounded-md"
        >
          Save
        </button>
      )}
    </div>
  );
};

export default AddTag;
