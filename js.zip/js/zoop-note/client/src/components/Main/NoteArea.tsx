import AddTag from "./AddTag";

import { ActiveNoteProps, UpdateNoteProps } from "../../App";
import { useRef } from "react";

type NoteAreaProps = {
  activeNote: ActiveNoteProps;
  updateNote: UpdateNoteProps;
};

//! issue: note area does not update on active note change
//? ref and state changes but not the input value
const NoteArea = ({ activeNote, updateNote }: NoteAreaProps) => {
  const titleRef = useRef<HTMLInputElement>(null);
  const bodyRef = useRef<HTMLTextAreaElement>(null);

  if (!activeNote) {
    return (
      <p className="flex-1 flex justify-center h-screen items-center border-2 border-blue-300">
        No note selected.
      </p>
    );
  }

  return (
    <div className="flex-1 min-h-full border-2 border-blue-300">
      <AddTag
        activeNote={activeNote}
        updateNote={updateNote}
        title={titleRef.current?.value || ""}
        body={bodyRef.current?.value || ""}
      />

      <div className="p-8">
        {/* TITLE */}
        <h3 className="mb-6 pb-1 border-b">
          <input
            ref={titleRef}
            defaultValue={activeNote.title}
            name="title"
            type="text"
            placeholder="Title..."
            className="w-full p-2 text-4xl border-0 outline-none"
          />
        </h3>

        {/* BODY */}
        <textarea
          ref={bodyRef}
          defaultValue={activeNote.body}
          name="body"
          spellCheck="false"
          placeholder="Write a note..."
          className="w-full h-96 outline-none resize-none"
        />
      </div>
    </div>
  );
};

export default NoteArea;
