import NoteMenuSlug from "./NoteMenuSlug";
import TagList from "./TagList";

import { NoteProps } from "../../App";

type NotesListProps = {
  notes: NoteProps[];
  activeNote: NoteProps | null;
  setActiveNote: (note: NoteProps) => void;
};

const NotesList = ({ notes, activeNote, setActiveNote }: NotesListProps) => {
  return (
    <div className="w-1/4 bg-blue-50">
      <TagList />
      <ul>
        {notes.map((note) => {
          return (
            <NoteMenuSlug
              key={note.id}
              note={note}
              active={activeNote?.id === note.id ? true : false}
              setActiveNote={setActiveNote}
            />
          );
        })}
      </ul>
    </div>
  );
};

export default NotesList;
