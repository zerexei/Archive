type IconProps = {
  color: string;
  opacity?: string | number;
  size?: string;
};

// SEARCH ICON
const SearchIcon = ({ color, opacity = 400 }: IconProps) => {
  const css = `h-6 w-6 text-${color}-${opacity}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={css}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
      />
    </svg>
  );
};

// PLUS ICON
const PlusIcon = ({ color, opacity = 400 }: IconProps) => {
  const css = `h-6 w-6 text-${color}-${opacity}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={css}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M12 6v6m0 0v6m0-6h6m-6 0H6"
      />
    </svg>
  );
};

// INFORMATION ICON
const InfoIcon = ({ color, opacity = 400 }: IconProps) => {
  const css = `h-6 w-6 text-${color}-${opacity}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={css}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
      />
    </svg>
  );
};

// CLOCK ICON
const ClockIcon = ({ color, opacity = 400 }: IconProps) => {
  const css = `h-6 w-6 text-${color}-${opacity}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={css}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
      />
    </svg>
  );
};

// TRASH ICON
const TrashIcon = ({ color, opacity = 400 }: IconProps) => {
  const css = `h-6 w-6 text-${color}-${opacity}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={css}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
      />
    </svg>
  );
};

// HORIZONTAL DOTS ICON
const DotsIcon = ({ color, opacity = 400 }: IconProps) => {
  const css = `h-6 w-6 text-${color}-${opacity}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={css}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"
      />
    </svg>
  );
};

// CHEVRON DOWN ICON
const ChevronDownIcon = ({ color, opacity = 400, size = "md" }: IconProps) => {
  let sizeCss = size;

  switch (size) {
    case "sm":
      sizeCss = "h-4 w-4";
      break;
    case "md":
      sizeCss = "h-6 w-6";
      break;
    case "lg":
      sizeCss = "h-8 w-8";
      break;
    default:
      sizeCss = "h-6 w-6";
      break;
  }

  const css = `${sizeCss} text-${color}-${opacity}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={css}
      viewBox="0 0 20 20"
      fill="currentColor"
    >
      <path
        fillRule="evenodd"
        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
        clipRule="evenodd"
      />
    </svg>
  );
};

export {
  SearchIcon,
  PlusIcon,
  InfoIcon,
  ClockIcon,
  TrashIcon,
  DotsIcon,
  ChevronDownIcon,
};
