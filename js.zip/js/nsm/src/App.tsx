import { useState } from "react";
// import logo from "./logo.svg";
import "./App.css";

type StaffProps = {
  id: number;
  name: string;
  checks: boolean[];
};

function App() {
  const [staffs, setStaffs] = useState<StaffProps[]>([
    { id: 1, name: "Proin hendrerit", checks: [true, false, true, false] },
    // { id: 2, name: "tortor diam", checks: [1, 0, 0, 1] },
    // { id: 3, name: "et fermentum", checks: [0, 1, 1, 0] },
    // { id: 4, name: "risus rutrum eget", checks: [1, 0, 1, 0] },
    // { id: 5, name: "Sed pretium", checks: [1, 1, 0, 1] },
  ]);
  const days: number[] = [1, 2, 3, 4, 5];

  const checked = (id: number, index: number, check: boolean) => {
    let updatedStaffs = staffs.map((staff) => {
      if (staff.id === id) staff.checks[index] = !check;
      return staff;
    });
    setStaffs(updatedStaffs);
  };

  // TODO: algorithm for generating checks w/ rules(ex. max of 3 checks per day)
  // const generate = (staffs: StaffProps[]) => {
  //   const newStaffs = staffs.map((staff) => ({...staff, checks: [ ...staff.checks, 1]}));
  //   setStaffs(newStaffs);
  //   console.log(newStaffs);
  //   console.log(staffs.sort(() => Math.random() - 0.5));
  // };

  return (
    <div className="p-12">
      <div className="flex flex-col">
        <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
            <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Name
                    </th>

                    {days.map((day, i) => (
                      <th
                        key={i}
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider text-center"
                      >
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {staffs.map((staff) => (
                    <tr key={staff.id} className="w-12">
                      <td className="px-6 py-4 whitespace-nowrap border">
                        <h2 className="text-sm font-medium text-gray-900">
                          {staff.name}
                        </h2>
                      </td>
                      {staff.checks.map((check, i) => (
                        <td
                          onClick={() => checked(staff.id, i, check)}
                          key={i}
                          className="px-6 py-4 whitespace-nowrap text-center border cursor-pointer hover:bg-gray-50"
                        >
                          <div className="text-sm text-gray-900">
                            {check ? `✓` : ""}
                          </div>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
