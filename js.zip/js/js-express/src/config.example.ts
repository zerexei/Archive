const config = {
  /** CUSTOM_CONFIG */
};

const db = {
  protocol: "DB_PROTOCOL",
  usename: "DB_USERNAME",
  password: "DB_PASSWORD",
  host: "DB_HOST",
  options: "DB_OPTIONS",
};

export { config, db };
