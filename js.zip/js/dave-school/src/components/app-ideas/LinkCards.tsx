import LinkCard from "./LinkCard";

const LinkCards = () => {
  return (
    <div className="flex flex-wrap gap-2 justify-center">
      <LinkCard path="/bin2dec" label="Bin2Dec" />
    </div>
  );
};

export default LinkCards;
