import { useEffect, useRef, useState } from "react";

const WhatColor = () => {
  const [color, setColor] = useState<string>("white");
  const [feedback, setFeedback] = useState("gray");
  const [points, setPoints] = useState(0);
  const answer = useRef<HTMLInputElement>(null);
  const colors = ["red", "blue", "green"];

  useEffect(() => {
    generateColor();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // check the answer of the user and generate new color if correct
  function checkAnswer() {
    if (!answer.current) return;

    if (answer.current.value !== color) {
      setFeedback("red");
      return;
    }

    setPoints(points + 100);
    setFeedback("green");
    generateColor();
    answer.current.value = "";
  }

  // set a random color to `color state` that is not the same as previous color
  function generateColor() {
    let randomColor = colors[Math.floor(Math.random() * colors.length)];

    while (randomColor === color) {
      randomColor = colors[Math.floor(Math.random() * colors.length)];
    }

    setColor(randomColor);
  }

  return (
    <div>
      {/* DESCRIPTION */}
      <p className="mb-6 text-gray-700 text-center tracking-wide">
        Determine the color inside the box.
      </p>

      {/* USER SCORE */}
      <p>Points: {points}</p>

      {/* COLOR BOX */}
      <div className={`p-12 mb-6 bg-${color}-400`}></div>

      {/* CONTROLS */}
      <input
        ref={answer}
        type="text"
        className={`p-2 mr-1 border-2 border-${feedback}-200`}
      />
      <button
        onClick={checkAnswer}
        className="py-2 px-4 bg-blue-400 text-white rounded"
      >
        Check
      </button>
    </div>
  );
};

export default WhatColor;
