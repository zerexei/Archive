<template>
  <div class="about">
    <h1>This is an about page</h1>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem
      odio illum accusamus corporis dolor nam incidunt perspiciatis eius. Fugiat
      quas enim aspernatur ipsa odit magni non, ducimus rerum aut. Qui.
    </p>
  </div>
</template>
