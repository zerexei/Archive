<template>
  <div class="pb-4">
    <div class="relative z-10 bg-white p-4 pt-6 shadow">
      <nav class="flex items-center">
        <router-link class="mr-4 text-gray-700 hover:text-gray-900" to="/"
          >Home</router-link
        >
        <router-link class="text-gray-700 hover:text-gray-900" to="/about"
          >About</router-link
        >
      </nav>
    </div>
  </div>
</template>