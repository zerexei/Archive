import Amazon from "./components/amazon-clone/Amazon";
// import Calculator from "./components/calculator/Calculator";

function App() {
  return (
    <div className="App m-12">
      <Amazon />
      {/* <Calculator /> */}
    </div>
  );
}

export default App;
