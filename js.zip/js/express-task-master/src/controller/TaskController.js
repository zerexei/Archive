import Prisma from "@prisma/client";
const { PrismaClient } = Prisma;

const DB = new PrismaClient();

/**
 * index - Get all tasks
 *
 * @return Promise<array>
 */
async function getAllTasks() {
  const tasks = await DB.task.findMany();
  return tasks;
}

/**
 * show - Get a task
 *
 * @param key integer
 * @return Promise<array> | null
 */
async function getTask(key) {
  key = Number(key);

  if (!isKey(key)) throw "Invalid key, Integer key only";

  const task = await DB.task.findUnique({
    where: {
      id: key,
    },
  });

  return task;
}

/**
 * store - create a new task
 * 
 * @param task object
 * @return Promise<object>
 */
async function createNewTask(task) {
  if (task.completed == null) {
    delete task.completed;
  }

  const createdTask = await DB.task.create({
    data: task,
  });

  return createdTask;
}

/**
 * update - update a task
 * 
 * @param key integer
 * @param task object
 * @return Promise<object>
 */
async function updateTask(key, task) {
  key = Number(key);

  if (!isKey(key)) throw "Invalid key, Integer key only";

  if (task.completed == null) {
    delete task.completed;
  }

  const updatedTask = await DB.task.update({
    where: {
      id: key,
    },
    data: task,
  });

  return updatedTask;
}

/**
 * destroy - delete a task
 * 
 * @param ke integer
 * @return Promise<object>
 */
async function deleteTask(key) {
  key = Number(key);
  
  if (!isKey(key)) throw "Invalid key, Integer key only";

  const result = await DB.task.delete({
    where: {
      id: key,
    },
  });

  return result;
}

/**
 * check if key is an integer
 *
 * @param key integer
 * @return boolean
 */
function isKey(key) {
  key = Number(key);

  return key === NaN || key % 1 !== 0 ? false : true;
}

export { getAllTasks, createNewTask, getTask, updateTask, deleteTask };
