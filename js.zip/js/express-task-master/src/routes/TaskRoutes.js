import express from "express";

// controller
import {
  createNewTask,
  deleteTask,
  getAllTasks,
  getTask,
  updateTask,
} from "./../controller/TaskController.js";

// router
const router = express.Router();

// example.com/api/tasks
router.route("/").get(async (req, res) => {
  const tasks = await getAllTasks();

  res.json(tasks);
});

// example.com/api/tasks
router.route("/").post(async (req, res) => {
  const task = {
    name: req.body.task,
    completed: req.body?.completed,
  };

  const createdTask = await createNewTask(task);

  res.json(createdTask);
});

// example.com/api/tasks/1
router.route("/:id").get(async (req, res) => {
  const id = req.params?.id;
  const task = await getTask(id);

  res.json(task);
});

// example.com/api/tasks/1
router.route("/:id").put(async (req, res) => {
  const id = req.params?.id;
  const task = {
    name: req.body.task,
    completed: req.body?.completed,
  };
  const updatedTask = await updateTask(id, task);

  res.json(updatedTask);
});

// example.com/api/tasks/1
router.route("/:id").delete(async (req, res) => {
  const id = req.params?.id;
  const deletedTask = await deleteTask(id);

  res.json(deletedTask);
});

export default router;
