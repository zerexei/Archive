import express from "express";

// routes
import routes_task from "./src/routes/TaskRoutes.js";

const app = express();

// middleware
app.use(express.json());

// Task route
app.use("/api/tasks", routes_task);

// welcome route
app.get("/", (req, res) => res.send("Hello World!"));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Listening on port: ${PORT}`));
