1. fork respo
2.
git remote add upstream <original ssh url>
git fetch upstream
git branch --set-upsteam-to=upstream/<branch> <local-branch>

3. create a branch and switch to branch
4. modify changes
5. git commit -m "comment"
6. git push --set-upstream <remote> <branch>
