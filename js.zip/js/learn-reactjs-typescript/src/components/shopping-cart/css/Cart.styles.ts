import styled from "styled-components";

export const Wrapper = styled.aside`
  font-family: Arial;
  width: 500px;
  padding: 20px;
`;
