<template>
  <div class="font-sans mx-12 my-8">
    <div class="draggable">
      <Header brandName="MadeWithVuejs" />
    </div>
    <div class="draggable">
      <HeroImage />
    </div>
    <div class="draggable">
      <Service />
    </div>
    <div class="draggable">
      <Paragraph />
    </div>
    <div class="draggable">
      <About />
    </div>

    <!-- <div class="drop-zone">
      <div
        v-for="item in getLists(1)"
        :key="item.id"
        draggable="true"
        @dragstart="startDrag($event, item)"
        class="drag-el p-2 bg-gray-200 mb-2 cursor-pointer"
      >
        {{ item.title }}
      </div>
    </div> -->
  </div>
</template>

<script>
import { onMounted } from 'vue'
import Header from "./components/Header.vue";
import HeroImage from "./components/HeroImage.vue";
import Service from "./components/Service.vue";
import Paragraph from "./components/Paragraph.vue";
import About from "./components/About.vue";

export default {
  name: "App",
  components: {
    Header,
    HeroImage,
    Service,
    Paragraph,
    About,
  },
  // COMPOSITION API
  setup() {
    const items = document.querySelectorAll(".draggable");

    onMounted(() => {
      console.log(items);
    });

    const getLists = (list) => {
      return items.value.filter((item) => item.list == list);
    };

    const startDrag = (event, item) => {
      console.log(item);
      event.dataTransfer.dropEffect = "move";
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("itemID", item.id);
    };

    const onDrop = (event, list) => {
      const itemID = event.dataTransfer.getData("itemID");
      const item = items.value.find((item) => item.id === itemID);
      item.list = list;
    };

    return {
      getLists,
      startDrag,
      onDrop,
    };
  },
};
</script>

<style>
</style>
