<template>
  <div class="mb-12">
    <h2 class="text-2xl font-bold mb-4 underline">Lorem Ipsum?</h2>
    <p class="tracking-wide text-gray-900">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum odit,
      eveniet quidem vero possimus facere, temporibus officia deserunt, at illo
      consequuntur aliquid voluptatum eum dolores iure molestias repudiandae
      illum enim. Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum
      odit, eveniet quidem vero possimus facere, temporibus officia deserunt, at
      illo consequuntur aliquid voluptatum eum dolores iure molestias
      repudiandae illum enim. Lorem ipsum dolor sit amet consectetur adipisicing
      elit. Ipsum odit, eveniet quidem vero possimus facere, temporibus officia
      deserunt, at illo consequuntur aliquid voluptatum eum dolores iure
      molestias repudiandae illum enim.
    </p>
  </div>
</template>

<script>
export default {
  name: "Paragraph",
};
</script>