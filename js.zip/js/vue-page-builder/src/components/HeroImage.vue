<template>
  <div class="relative h-96 w-full mb-12 bg-green-400">
    <!-- INFORMATION -->
    <div
      class="flex flex-col gap-5 absolute top-1/2 left-1/2 p-4 text-center bg-white bg-opacity-50 rounded-md"
      style="transform: translate(-50%, -50%)"
    >
      <h2 class="text-2xl font-semibold">Welcome to Page Builder</h2>

      <p class="tracking-wider">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed ut
        officiis, eaque suscipit exercitationem facilis cumque obcaecati placeat
        quasi impedit repellat. Est illum rem culpa adipisci esse? Nesciunt, vel
        nostrum!
      </p>

      <button
        class="self-center py-2 px-4 rounded text-white tracking-wide bg-black border-2 border-transparent rounded
          hover:bg-transparent hover:text-black hover:border-black"
      >
        Explore
      </button>
    </div>

    <!-- BACKGROUND IMAGE -->
    <img
      src="https://picsum.photos/1000/300"
      alt="random image"
      class="w-full h-full object-cover rounded"
    />
  </div>
</template>

<script>
export default {
  name: "HeroImage",
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
