<template>
 <div class="flex-1 p-2 pb-6 text-center rounded">
        <h2 class="mb-2 text-xl font-semibold">{{ label }}</h2>
        <Scale classes="w-20 h-20 mx-auto mb-2 text-green-700" />
        <p class="flex-1 mb-6 text-sm">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Est molestiae
          necessitatibus consectetur? Doloremque deserunt rem eveniet hic magni
          voluptates laboriosam autem, ex eaque laudantium voluptatum, optio
          repellendus suscipit debitis vel?
        </p>
        <button class="py-2 px-8 tracking-wide font-bold border-2 border-gray-700 rounded">
          More...
        </button>
      </div>	
</template>

<script>
import Scale from "./icons/Scale.vue";

export default {
	name: "ServiceCard",
  components: {
    Scale,
  }, 
  props: {
    label: String
  }
}
</script>