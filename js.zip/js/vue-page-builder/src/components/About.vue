<template>
  <div class="flex justify-center items-center p-8 bg-gray-400 rounded">
    <!-- ABOUT LEFT CONTENT -->
    <div class="w-1/3 mr-20">
      <h2 class="text-4xl font-bold mb-2 text-white">About us</h2>
      <p class="text-gray-50 tracking-wide">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis,
        perferendis temporibus magni quaerat qui dicta quia quo adipisci
        repudiandae enim illo a nisi sed repellat eius! Impedit magnam
        laudantium error.
      </p>
    </div>
    <!-- ABOUT RIGHT CONTENT -->
    <div>
      <img
        src="https://picsum.photos/200"
        alt="random image"
        class="w-full h-64 object-cover mx-auto rounded-full"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "About",
};
</script>