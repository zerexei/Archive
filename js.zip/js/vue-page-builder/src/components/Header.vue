<template>
  <div class="flex justify-between items-center h-20 mb-6">
    <!-- BRAND -->
    <div class="text-2xl font-bold text-green-700">
      <h1>{{ brandName }}</h1>
    </div>

    <!-- NAVIGATIONS -->
    <nav class="flex gap-2 items-center text-gray-900">
      <a href="#" class="p-2 hover:text-green-400">Home</a>
      <a href="#" class="p-2 hover:text-green-400">Profile</a>
      <a href="#" class="p-2 hover:text-green-400">Contact</a>

      <!-- AUTHENTICATION -->
      <a
        href="#"
        class="py-2 px-4 text-green-700 border-2 border-green-400 rounded"
        >Sign up
      </a>
    </nav>
  </div>
</template>

<script>
export default {
  name: "Header",
  props: {
    brandName: String,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
