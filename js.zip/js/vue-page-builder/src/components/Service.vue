<template>
  <div class="mb-12">
    <div class="flex gap-5 mb-6">
      <ServiceCard label="Service I" />
      <ServiceCard label="Service II" />
      <ServiceCard label="Service III" />
    </div>
  </div>
</template>

<script>
import ServiceCard from "./ServiceCard";

export default {
  name: "Service",
  components: {
    ServiceCard,
  },
};
</script>