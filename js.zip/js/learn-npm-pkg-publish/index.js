import 'grapesjs/dist/css/grapes.min.css';
import grapesjs from 'grapesjs';

export default grapesjs.plugins.add('zerexei-grapejs-component', (editor, options) => {
  /*
  * Here you should rely on GrapesJS APIs, so check 'API Reference' for more info
  * For example, you could do something like this to add some new command:
  *
  * editor.Commands.add(...);
  */

  editor.BlockManager.add('my-first-block', {
        label: 'Simple block',
        content: '<div class="my-block">This is a simple block</div>',
      });
})