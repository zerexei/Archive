async function search(target) {
  const req = await fetch(
    "https://kitsu.io/api/edge/anime?page[limit]=20"
  );
  const res = (await req.json()).data;
 console.log(res.length);
  const cards = res.map((d) => {
    const ani = {
      title: d.attributes.titles.en,
      description: d.attributes.description,
      image_url: d.attributes.posterImage.large,
      attributes: [

        episodes: d.attributes.episodeCount,
        ageRating => d.attributes.ageRating,
        nsfw => d.attributes.nsfw,
      ]
    };
    
  });
}
function el({}) {
  return `<div class="card">
            <div class="card__header">
              <img src="${image_url}" alt="anime cover image" />
            </div>
            <div class="card__content">
              <h2 class="card__content__title">${title}</h2>
              <p class="card__content__body">${description}</p>
            </div>
            <div class="card__footer">
              ${badges(attributes)}
            </div>
          </div>`
}

function badges(attributes) {
  const el = '';
  attributes.map( => {
    el += `<span>${}</span>`
  })
}
search('')

