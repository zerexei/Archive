const Home = () => {
  return (
    <div>
      <h2>Welcome user!</h2>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum, iste
        eaque quidem maxime dolore mollitia debitis quas beatae possimus porro!
        Deleniti repellat iste aliquam nostrum inventore fugiat totam sint
        corrupti.
      </p>
    </div>
  );
};

export default Home;
