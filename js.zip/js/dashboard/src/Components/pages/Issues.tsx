import React from "react";

const Issues = () => {
  return (
    <div>
      <h2>Issues</h2>
    </div>
  );
};

export default Issues;
