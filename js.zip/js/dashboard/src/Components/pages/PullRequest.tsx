import React from "react";

const PullRequest = () => {
  return (
    <div>
      <h2>Pull Request</h2>
    </div>
  );
};

export default PullRequest;
