# Vite Build

```js
{
    "watch": "vite build --watch",
}
```

- hashed build files

  - https://www.keycdn.com/support/what-is-cache-busting

- rollupOptions
- webpack for vite

- vite --force
  - ignore dependency cache then reforce all dependency
  

