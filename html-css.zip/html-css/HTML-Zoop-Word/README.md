# zoop-word
Search or generate a random word with definition using the Merriam-Webster Dictionary API

Made using HTML5, Tailwindcss and Javascript.
