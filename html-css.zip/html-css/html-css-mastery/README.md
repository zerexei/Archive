# Welcome to my HTML CSS Learning Journey
- compiled learning resources completed