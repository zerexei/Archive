<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>

    <!-- Fonts -->

    <!-- Stylesheets -->
    <link rel="stylesheet" href="#">

    <!-- Scripts -->
    <script src="#" defer></script>
</head>

<body>
    <header>
        <!-- Header -->
        <nav>
            <a href="#">Home</a>
            <a href="#">Users</a>
            <a href="#">About</a>
        </nav>
    </header>
    <main>
        <div class="container">
            <!-- Main content -->

        </div>
    </main>
    <footer>
        <!-- Footer -->
    </footer>
</body>

</html>