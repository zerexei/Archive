<?php

namespace App\Controllers;

use App\Models\User;

class UserController
{
}
