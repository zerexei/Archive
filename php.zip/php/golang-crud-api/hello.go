package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"

	_ "github.com/mattn/go-sqlite3"
)

// !NOTE: golang uses lowercase for private & uppercase for public
type User struct {
	Id       int
	Email    string
	Password string
}

// (C) create user
func store(w http.ResponseWriter, req *http.Request) {
	var user User

	err := json.NewDecoder(req.Body).Decode(&user)

	if err != nil {
		panic(err)
	}

	db, err := sql.Open("sqlite3", "test.db")

	if err != nil {
		panic(err)
	}

	defer db.Close()

	stmt := fmt.Sprintf("INSERT INTO users (email, password) VALUES ('%s', '%s')", user.Email, user.Password)

	_, err = db.Exec(stmt)

	if err != nil {
		panic(err)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode("User Created.")
}

// (R) show user
func show(w http.ResponseWriter, req *http.Request) {
	var user User

	err := json.NewDecoder(req.Body).Decode(&user)

	if err != nil {
		panic(err)
	}

	db, err := sql.Open("sqlite3", "test.db")

	if err != nil {
		panic(err)
	}

	defer db.Close()

	var id int
	var email string
	var password string

	row := db.QueryRow("SELECT * FROM users WHERE email = ?", user.Email)
	err = row.Scan(&id, &email, &password)

	json.NewEncoder(w).Encode(fmt.Sprintf("%d - %s - %s", id, email, password))
}

// (U) update user
func update(w http.ResponseWriter, req *http.Request) {
	var user User

	err := json.NewDecoder(req.Body).Decode(&user)
	if err != nil {
		panic(err)
	}

	stmt := fmt.Sprintf("UPDATE users SET email = '%s', password = '%s' WHERE id = '%d'", user.Email, user.Password, user.Id)
	DB_execute(stmt)

	json.NewEncoder(w).Encode("User Updated.")
}

// (D) delete user
func destroy(w http.ResponseWriter, req *http.Request) {
	var user User

	err := json.NewDecoder(req.Body).Decode(&user)
	if err != nil {
		panic(err)
	}

	stmt := fmt.Sprintf("DELETE FROM users WHERE id = '%d'", user.Id)
	DB_execute(stmt)

	json.NewEncoder(w).Encode("User deleted.")
}

func headers(w http.ResponseWriter, req *http.Request) {

	for name, headers := range req.Header {
		for _, h := range headers {
			fmt.Fprintf(w, "%v: %v\n", name, h)
		}
	}
}

func main() {
	createUsersTable()
	http.HandleFunc("/store", store)
	http.HandleFunc("/show", show)
	http.HandleFunc("/update", update)
	http.HandleFunc("/delete", destroy)
	http.HandleFunc("/headers", headers)

	http.ListenAndServe(":3001", nil)
}

func createUsersTable() {
	stmt := `
		DROP TABLE IF EXISTS users;
		CREATE TABLE users(id INTEGER PRIMARY KEY, email VARCHAR, password TEXT);
	`
	DB_execute(stmt)
}

func DB_execute(stmt string) sql.Result {
	db, err := sql.Open("sqlite3", "test.db")

	if err != nil {
		panic(err)
	}

	defer db.Close()

	res, err := db.Exec(stmt)

	if err != nil {
		panic(err)
	}

	return res
}

func DB_query(stmt string) *sql.Rows {
	db, err := sql.Open("sqlite3", "test.db")

	if err != nil {
		panic(err)
	}

	defer db.Close()

	rows, err := db.Query(stmt)

	if err != nil {
		panic(err)
	}

	defer rows.Close()

	return rows
}
