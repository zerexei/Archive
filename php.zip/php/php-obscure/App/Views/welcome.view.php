<?php require_once 'includes/_header.php'; ?>

<?php render('users.create', ['courses' => $courses])?>

<?php require_once 'includes/_footer.php'; ?>