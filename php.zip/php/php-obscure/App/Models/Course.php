<?php

namespace App\Models;

use Core\Blueprint\Models;

class Course extends Models
{
    protected $table = 'course';

}