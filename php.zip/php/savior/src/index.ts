import express from "express";
import cors from "cors";
import AuthRoutes from "./Routes/AuthRoutes";
import PostRoutes from "./Routes/PostRoutes";

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post("/", (req, res) => res.status(200).send("Working..."));
app.use("/auth", AuthRoutes);
app.use("/posts", PostRoutes);

const port = process.env.PORT || 3001;

app.listen(port, () => console.log(`listening: http://127.0.0.1:${port}`));
