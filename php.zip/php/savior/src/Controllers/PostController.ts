import { Request, Response } from "express";
import { Post, PrismaClient } from "@prisma/client";

type ControllerProps = (req: Request, res: Response) => Promise<Response>;

const prisma = new PrismaClient();

// TODO: validate inputs
const allPost: ControllerProps = async (req, res) => {
  // await prisma.user.create({
  //   data: {
  //     email: "email@mail.com",
  //     password: "password",
  //   },
  // });
  // await prisma.post.createMany({
  //   data: [
  //     { author_id: 1, title: "post title 1", body: "post body 1" },
  //     { author_id: 1, title: "post title 2", body: "post body 2" },
  //     { author_id: 1, title: "post title 3", body: "post body 3" },
  //     { author_id: 1, title: "post title 4", body: "post body 4" },
  //     { author_id: 1, title: "post title 5", body: "post body 5" },
  //   ],
  // });
  const posts = await prisma.post.findMany();
  return res.status(200).send(posts);
};

const createPost: ControllerProps = async (req, res) => {
  const post: Post = await prisma.post.create({
    data: {
      author_id: req.body._id,
      title: req.body.title,
      body: req.body.body,
    },
  });

  if (!post) {
    return res.status(503).send("Failed creating post.");
  }

  return res.status(200).send(post);
};

const updatePost: ControllerProps = async (req, res) => {
  try {
    const post = await prisma.post.update({
      where: { id: Number(req.params.id) },
      data: {
        title: req.body?.title,
        body: req.body?.body,
      },
    });
    return res.status(200).send(post);
  } catch (error) {
    return res.status(500).send(error);
  } finally {
    // close prisma every transaction
    await prisma.$disconnect();
  }
};

const deletePost: ControllerProps = async (req, res) => {
  try {
    await prisma.post.delete({
      where: { id: Number(req.params.id) },
    });
    return res.status(204);
  } catch (error) {
    return res
      .status(503)
      .send(`Record with an id of ${req.params.id} to delete does not exists`);
  } finally {
    // close prisma every transaction
    await prisma.$disconnect();
  }
};

export { allPost, createPost, updatePost, deletePost };
