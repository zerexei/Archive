import { Request, Response } from "express";
import { PrismaClient, User } from "@prisma/client";
import * as EmailValidator from "email-validator";

type ControllerProps = (req: Request, res: Response) => Promise<Response>;

const prisma = new PrismaClient();

// TODO: implement next
// app.post("/todos", async (req, res, next) => {
//   try {
//     const todo = await db.Todo.create(req.body)
//     return success(res, todo)
//   } catch (err) {
//     next({ status: 400, message: "failed to create todo" })
//   }
// })

// TODO: refactor
const register: ControllerProps = async (req, res) => {
  const isValidEmail = EmailValidator.validate(req.body.email);

  if (!isValidEmail) {
    return res.status(500).send(`Invalid email: ${req.body.email}`);
  }

  try {
    // TODO: validations
    const user: User = await prisma.user.create({
      data: {
        username: req.body?.username,
        email: req.body.email,
        password: req.body.password,
      },
    });
    return res.status(201).send(user);
  } catch (error) {
    return res.status(500).send("Failed creating user.");
  }
};

const login: ControllerProps = async (req, res) => {
  const isValidEmail = EmailValidator.validate(req.body.email);

  if (!isValidEmail) {
    return res.status(500).send(`Invalid email: ${req.body.email}`);
  }

  try {
    // TODO: validate
    const user = await prisma.user.findUnique({
      where: {
        email: req.body.email,
      },
    });

    if (user?.password !== req.body.password) {
      return res.status(500).send("Email or password didn't match.");
    }

    return res.status(200).send(user);
  } catch (error) {
    return res.status(500).send("Email or password didn't match.");
  }
};

const passwordReset: ControllerProps = async (req, res) => {
  const isValidEmail = EmailValidator.validate(req.body.email);

  if (!isValidEmail) {
    return res.status(500).send(`Invalid email: ${req.body.email}`);
  }

  try {
    const user: User = await prisma.user.update({
      where: {
        id: Number(req.body._id),
      },
      data: {
        password: req.body.password,
      },
    });

    return res.status(200).send(user);
  } catch (error) {
    return res.status(500).send("Failed updating user.");
  }
};

export { register, login, passwordReset };

// // Login
// Logout
// // Register
// Forgot password
// Change password
// Email Verification
