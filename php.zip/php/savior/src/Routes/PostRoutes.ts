import express from "express";
import {
  allPost,
  createPost,
  deletePost,
  updatePost,
} from "./../Controllers/PostController";

const router = express.Router();

// create
// read/read all
// update
// delete
router.get("/", allPost);
router.post("/", createPost);
router.put("/:id", updatePost);
router.delete("/:id/delete", deletePost);

export default router;
