import express from "express";
import {
  register,
  login,
  passwordReset,
} from "./../Controllers/AuthController";

const router = express.Router();

router.post("/register", register);
router.post("/login", login);
router.patch("/password/reset", passwordReset);

export default router;
