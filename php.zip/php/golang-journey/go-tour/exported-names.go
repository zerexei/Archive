package main

import (
	"fmt"
	"math"
)

func main() {

	// math.Pi // public
	// math.pi // private
	fmt.Println(math.Pi)
}
