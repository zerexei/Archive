<?php
return [
    'database' => [
        'name' => 'DATABASE_NAME',
        'username' => 'DATABASE_USERNAME',
        'password' => 'DATABASE_PASSWORD',
        'connection' => 'DATABASE_CONNECTION',
        'options' => [
            'CONNECTION_OPTIONS'
        ],
    ],
];
