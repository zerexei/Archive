<?php

namespace App\Controllers;

class PagesController
{
    public function welcome()
    {
        // TODO: 
        return view('welcome');
    }    
}
