package greetings

import "fmt"

// capitalize to export a function/variable
func Greet() {

	// static
	var name string = "John Doe"

	// dynamic
	greet := fmt.Sprintf("Hello, %v!", name)
	// firstName, lastName := "John", "Doe"

	fmt.Println(greet)
}
