package main

import (
	"explore/greetings"
	"fmt"
)

func main() {
	// * Variable declaration shortcuts
	// variable := type{value}
	// variable := value

	greetings.Greet()
	// callArray()
	// callIf()
	// callSwitch()
	// callLoop()
	// callMap()
	// callRange()
	// callPointer()
	// callClosure()
	// callStruct()
	callInterface()

}

func callArray() {
	var fruits [2]string
	fruits[0] = "apple"
	fruits[1] = "orange"

	fruits2 := [2]string{"apple", "orange"}

	fmt.Println(fruits, fruits2)
}

func callIf() {
	x := 1
	y := 2
	if x > y {
		fmt.Println("x is greater than y")
	} else if x == y {
		fmt.Println("x is equal to y")
	} else {
		fmt.Println("y is greater than x")
	}
}

func callSwitch() {
	// color := "Red"
	// switch color {
	switch color := "Blue"; color {
	case "Red":
		fmt.Println("The color is red")
	case "Blue":
		fmt.Println("The color is blue")
	default:
		fmt.Println("The color is invalid")
	}

}

func callLoop() {
	for i := 0; i < 10; i++ {
		fmt.Printf("loop %v\n", i)
	}
}

func callMap() {
	// stars := make(map[string]int)
	// stars["one"] = 1
	// stars["two"] = 2
	// stars["three"] = 3

	stars := map[string]int{
		"one":   1,
		"two":   2,
		"three": 3,
	}

	// delete an entry from a map
	delete(stars, "one")

	fmt.Println(stars)
}

/**
 * Range
 */
func callRange() {
	// list := []int{2, 4, 16, 256, 65536}
	list := map[string]string{"one": "1", "two": "2", "three": "3"}

	// iterate over iterable
	for key, value := range list {
		fmt.Printf("key: %v - value: %v\n", key, value)
	}

}

func callPointer() {
	a := 2
	b := &a // set pointer

	fmt.Println(*b) // get pointer
	// fmt.Println(*&a) // same as *b
	fmt.Println(b) // pointer

	*b = 5 // change the value of variable `a` using a pointer
	fmt.Println(a)
}

func adder() func(int) int {
	sum := 0
	return func(x int) int {
		sum += x
		return sum
	}

	// * javascript
	// function adder() {
	// 	var sum = 0
	// 	return function (x) {
	// 		sum += x
	// 		return sum
	// 	}
	// }
}

func callClosure() {
	sum := adder()

	for i := 0; i < 10; i++ {
		fmt.Println(sum(i))
	}

}

// * struct
type Person struct {
	firstName string
	lastName  string
	age       int
}

// Add a method for Person struct
func (p Person) greet() string {
	return "Hello, " + p.firstName + " " + p.lastName
}

// using a pointer on method
func (p *Person) incrementAge() {
	p.age += 1
}

func callStruct() {
	person1 := Person{firstName: "John", lastName: "Doe", age: 12}
	person1.incrementAge()
	fmt.Println(person1, person1.greet())
}

// * interface
type Animal interface {
	getName() string
	setName(string)
}

type Dog struct {
	name string
}

type Cat struct {
	name string
}

func (c Cat) getName() string {
	return c.name
}

func (d Dog) getName() string {
	return d.name
}

func (d *Dog) setName(name string) {
	d.name = name
}

func getAnimalName(a Animal) string {
	return a.getName()
}

func setAnimalName(a Animal, name string) {
	a.setName(name)
}

func callInterface() {
	dog := &Dog{name: "John"}
	// cat := Cat{name: "Jane"}

	// *Dog !== Dog
	setAnimalName(dog, "Will")
	fmt.Printf("Dog name: %v\n", getAnimalName(dog))
	// fmt.Printf("Cat name: %v", getAnimalName(cat))

}

// type Shape interface {
// 	area() float64
// }

// type Circle struct {
// 	x, y, radius float64
// }

// type Rectangle struct {
// 	width, height float64
// }

// func (c Circle) area() float64 {
// 	return math.Pi * c.radius * c.radius
// }

// func (r Rectangle) area() float64 {
// 	return r.width * r.height
// }

// func getArea(s Shape) float64 {
// 	return s.area()
// }

// func callInterface() {
// 	circle := Circle{x: 0, y: 0, radius: 5}
// 	rectangle := Rectangle{width: 10, height: 5}
// 	fmt.Printf("Circle Area: %v\n", getArea(circle))
// 	fmt.Printf("Rectangle Area: %v", getArea(rectangle))
// }

/**
 * BASIC TYPES
 * bool
 * string
 * int  int8  int16  int32  int64
 * uint uint8 uint16 uint32 uint64 uintptr
 * byte // alias for uint8
 * rune // alias for int32
 *      // represents a Unicode code point
 * float32 float64
 * complex64 complex128
 */
