type NavLinkProps = {
  label: string;
  url: string;
};

const NavLink = ({ label, url }: NavLinkProps) => {
  return (
    <a 
      href={ url } 
      className="hover:text-gray-300"
    >
      { label }
    </a>
  );
};

export default NavLink;
