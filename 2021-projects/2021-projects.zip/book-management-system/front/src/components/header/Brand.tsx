const Brand = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-200">
        DAAAAVE!
      </h1>
    </div>
  );
};

export default Brand;
