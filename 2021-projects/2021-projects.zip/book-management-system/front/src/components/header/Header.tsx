import Brand from "./Brand";
// import { AccountSetting } from "./AccountSetting";
import NavBar from "./NavBar";

const Header = () => {
  return (
    <header className="bg-gray-800 text-gray-400">
      <div className="flex items-center justify-between w-3/4 h-20 mx-auto">
        <Brand />
        <NavBar />

        <div className="flex items-center gap-5 text-sm">
          <a href="#a">Login</a>
          <a href="#a" className="py-2 px-4 bg-blue-500 text-white rounded-md">
            Sign Up
          </a>
        </div>

        {/* <AccountSetting /> */}
      </div>
    </header>
  );
};

export default Header;
