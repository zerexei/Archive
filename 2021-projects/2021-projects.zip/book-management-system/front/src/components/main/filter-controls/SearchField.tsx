import { SearchIcon } from "@heroicons/react/solid";

const SearchField = () => {
  return (
    <div>
      {/* LABEL */}
      <h2 className="mb-2 text-sm">Search</h2>
      
      {/* FIELD */}
      <div className="flex items-center gap-2 p-2 bg-gray-800 rounded">
        <SearchIcon className="w-5 h-5 text-gray-500" />
        <input type="text" className="text-sm bg-transparent outline-none" />
      </div>
    </div>
  );
};

export default SearchField;
