import { EmojiHappyIcon } from "@heroicons/react/outline";
import Header from "./components/header/Header";
import FilterControl from "./components/main/FilterControl";
function App() {
  return (
    <div className="font-openSans">
      <Header />
      <main className="py-12 text-gray-200 bg-gray-900">
        <div className="w-3/4 mx-auto">
          <FilterControl />

          <section className="mb-6">
            <div className="flex justify-between items-end mb-4 text-gray-400">
              <h2 className="text-xl font-bold uppercase">trending now</h2>
              <p className="text-sm cursor-pointer">View All</p>
            </div>
            <div className="flex justify-between">
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">
                  Tensei Shitara Slime Datta Ken 2nd Season Part 2
                </p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
            </div>
          </section>

          <section className="mb-6">
            <div className="flex justify-between items-end mb-4 text-gray-400">
              <h2 className="text-xl font-bold uppercase">all time popular</h2>
              <p className="text-sm cursor-pointer">View All</p>
            </div>
            <div className="flex justify-between">
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">
                  Tensei Shitara Slime Datta Ken 2nd Season Part 2
                </p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
              <div className="w-1/6">
                <div className="h-72 w-full mb-2 bg-red-200 rounded"></div>
                <p className="text-sm">One Piece</p>
              </div>
            </div>
          </section>

          <section className="mb-6">
            {/* LABEL */}
            <div className="flex justify-between items-end mb-4 text-gray-400">
              <h2 className="text-xl font-bold uppercase">Top 100 Books</h2>
              <p className="text-sm cursor-pointer">View All</p>
            </div>

            {/* CONTAINER */}
            <div className="flex flex-col gap-5">
              {/* CARD */}
              <div className="flex p-2">
                {/* NUMBER */}
                <p className="p-4 text-gray-500">
                  # <span className=" -ml-2 text-4xl font-bold">1</span>
                </p>

                <div className="flex-1 flex items-center p-2 text-gray-500 bg-gray-300 rounded">
                  {/* AVATAR */}
                  <p className="p-6 mr-4 bg-red-400"></p>

                  <div className="flex-1">
                    <p>Gintama: THE FINAL</p>

                    {/* TAGS */}
                    <div className="flex items-end gap-2">
                      <span className="px-2 text-xs text-white bg-red-400 rounded-xl">
                        action
                      </span>
                      <span className="px-2 text-xs text-white bg-red-400 rounded-xl">
                        comedy
                      </span>
                      <span className="px-2 text-xs text-white bg-red-400 rounded-xl">
                        drama
                      </span>
                    </div>
                  </div>

                  {/* INFO */}
                  <div className="flex-1 flex">
                    <div className="w-1/3">
                      <p>
                        <EmojiHappyIcon className="inline-block w-5 h-5 text-green-400" />{" "}
                        90%
                      </p>
                      <p className="text-xs">158192 users</p>
                    </div>

                    <div className="w-1/3">
                      <p>TV Show</p>
                      <p className="text-xs">15 episodes</p>
                    </div>

                    <div className="w-1/3">
                      <p>Spring 2022</p>
                      <p className="text-xs">Finished</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;
