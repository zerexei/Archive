import { useState } from "react";

import { MenuAlt3Icon } from "@heroicons/react/solid";
import NavbarLink from "./NavbarLink";

const Header = () => {
  const [isActiveNav, setIsActiveNav] = useState(false);

  const toggleNav = () => {
    setIsActiveNav(!isActiveNav);
  };

  const nav = (
    <nav className="flex flex-col">
      <NavbarLink url="/" label="Home" />
      <NavbarLink url="/about" label="About" />
      <NavbarLink url="/contact" label="Contact" />
      <NavbarLink url="/signin" label="Sign in" />
    </nav>
  );

  return (
    <header className="pb-6">
      <div className="">
        {/* BRAND */}
        <div className="flex justify-between items-center">
          <h1 className="flex-1 mb-4 text-2xl font-bold text-red-400">
            Daaaave's School
          </h1>

          {/* MENU BAR */}
          <span>
            <MenuAlt3Icon
              onClick={toggleNav}
              className="inline-block h-8 w-8 cursor-pointer hover:text-red-400"
            />
          </span>
        </div>

        {/* NAVIGATION */}
        {isActiveNav && nav}
      </div>
    </header>
  );
};

export default Header;
