import { useEffect, useState } from "react";
import Facts from "./facts.json";

type FactProps = {
  id: number;
  statement: string;
  answer?: string;
  isFact: boolean;
};

const FactOrBluff = () => {
  const [fact, setFact] = useState({} as FactProps);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const randomFacts = Facts.sort(() => Math.random() - 0.5);
    setFact(randomFacts[0]);
  }, []);

  const isFact = () => checkAnswer(true);
  const isBluff = () => checkAnswer(false);

  const checkAnswer = (answer: boolean) => {
    // https://stackoverflow.com/questions/49555273/how-to-shuffle-an-array-of-objects-in-javascript
    let randomFacts = Facts.sort(() => Math.random() - 0.5);

    while (randomFacts[0] === fact) {
      randomFacts = Facts.sort(() => Math.random() - 0.5);
    }

    if (fact.isFact !== answer) {
      setScore(0);
      setFact(randomFacts[0]);
      alert("wrong");
      return;
    }

    setScore(score + 100);
    setFact(randomFacts[0]);
  };

  return (
    <div>
      <div className="flex justify-between">
        <p className="mb-6">
          Score: <span className="text-xl font-bold">{score}</span>
        </p>
        <p>
          Life: <span className="text-xl font-bold text-red-400">3</span>
        </p>
      </div>

      <div className="mb-6 p-4 bg-gray-200 rounded tracking-wide">
        <p className="mb-2 text-sm text-red-400 tracking-normal">
          Fact or bluff?
        </p>
        {fact && fact.statement}
      </div>
      <div className="flex justify-center gap-5">
        <button
          onClick={isFact}
          className="py-2 px-6 text-white bg-green-400 rounded"
        >
          Fact
        </button>
        <button className="py-2 px-6 text-white bg-blue-400 rounded">
          Restart
        </button>
        <button
          onClick={isBluff}
          className="py-2 px-6 text-white bg-red-400 rounded"
        >
          Bluff
        </button>
      </div>
    </div>
  );
};

export default FactOrBluff;
