import { Link, useRouteMatch } from "react-router-dom";

type linkCardProps = {
  path: string;
  label: string;
};

const LinkCard = ({ path, label }: linkCardProps) => {
  let { url } = useRouteMatch();

  return (
    <Link
      to={url + path}
      className="py-2 px-3 bg-red-400 text-white rounded-md"
    >
      {label}
    </Link>
  );
};

export default LinkCard;
