import { Link, Route, Switch, useRouteMatch } from "react-router-dom";

import LinkCards from "./LinkCards";

// apps
import Bin2Dec from "./Bin2Dec";

const AppIdeas = () => {
  let { path } = useRouteMatch();

  return (
    <div>
      <div className="mb-6 text-right">
        <Link
          to="/app-ideas"
          className="py-2 px-6 font-bold text-red-400 border-2 border-red-400 rounded"
        >
          All apps
        </Link>
      </div>

      <Switch>
        <Route exact path={path}>
          <h3 className="mb-12 text-4xl font-bold text-center">
            Welcome to App Ideas implementation
          </h3>

          <LinkCards />
        </Route>
   
        <Route path={`${path}/bin2dec`} component={Bin2Dec} />
      </Switch>
    </div>
  );
};

export default AppIdeas;
