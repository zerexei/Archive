import { useRef, useState } from "react";

const Bin2Dec = () => {
  const [decimal, setDecimal] = useState<number>(0);
  const binaryRef = useRef<HTMLInputElement>(null);

  const convertBinaryToDecimal = () => {
    if (binaryRef.current) {
      const binary = binaryRef.current.value;

      if (!binary.match(/^[10]+$/)) {
        binaryRef.current.value = "";
        setDecimal(0);
        return alert("Invalid binary value. Only accepting 1's and 0's.");
      }

      if (binary.length > 8) {
        setDecimal(0);
        return alert("max of 8 binary digits");
      }

      const result = parseInt(binary, 2);
      setDecimal(result);
    }
  };

  return (
    <div className="flex align-center flex-col gap-5">
      <p className="text-sm text-gray-700 text-center">
        Binary to decimal converter
      </p>

      <div>
        <label className="block mb-1 text-sm text-gray-700 font-bold">
          Binary
        </label>
        <input
          ref={binaryRef}
          type="number"
          className="w-full p-2 border border-red-400"
          placeholder="enter binary to convert to decimal."
        />
      </div>

      <button
        onClick={convertBinaryToDecimal}
        className="py-2 bg-blue-500 text-white rounded"
      >
        Convert
      </button>

      {<p className="text-center text-4xl font-bold">Decimal: {decimal}</p>}
    </div>
  );
};

export default Bin2Dec;
