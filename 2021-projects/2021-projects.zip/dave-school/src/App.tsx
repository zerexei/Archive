import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import AmIClear from "./components/AmIClear";
import AppIdeas from "./components/app-ideas/AppIdeas";
import Card from "./components/Card";
import Header from "./components/Header";
import IsPrime from "./components/games/IsPrime";
import WhatColor from "./components/games/WhatColor";

import Routes from "./routes.json";
import FactOrBluff from "./components/games/FactOrBluff/FactOrBluff";

type RoutesProps = {
  id: number;
  title: string;
  description: string;
  url: string;
};

// TODO: hear the word then spell it (use speech api)
const App = () => {
  // can be moved to state

  return (
    <Router>
      <div className="font-sans m-6 pb-6">
        <Header />
        <main className="flex flex-col gap-5">
          <Switch>
            <Route exact path="/">
              {Routes.map((route: RoutesProps) => (
                <Card
                  key={route.id}
                  title={route.title}
                  description={route.description}
                  url={route.url}
                />
              ))}
            </Route>
            <Route path="/is-prime" component={IsPrime} />
            <Route path="/what-color" component={WhatColor} />
            <Route path="/am-I-clear" component={AmIClear} />
            <Route path="/app-ideas" component={AppIdeas} />
            <Route path="/fact-or-bluff" component={FactOrBluff} />
          </Switch>
        </main>
      </div>
    </Router>
  );
};

export default App;
