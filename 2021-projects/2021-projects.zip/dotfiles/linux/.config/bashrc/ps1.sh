#!/bin/bash

export PS1="\e[0;37m\A \e[35m\u@\h\e[37m: \e[33m\W \n\e[37m> \e[1;32m"
