<?php

// reject some items from an array
function reject($items, $callback)
{
  $filtered_items = array_filter($items, $callback);
  $diff_items = array_diff($items, $filtered_items);
  return array_values($diff_items);
}

reject(['Apple', 'Pear', 'Kiwi', 'Banana'], function ($item) {
  return strlen($item) > 4;
}); // ['Pear', 'Kiwi']
