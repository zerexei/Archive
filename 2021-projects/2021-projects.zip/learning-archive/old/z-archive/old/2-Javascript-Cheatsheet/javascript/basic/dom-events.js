
hasFocus - true if web page has window focus
write( text ) - specified text to web page
writeln( text ) - specified text to web page followed by newline char
onerror - on error loading required file for web page
onhaschange - on server address of url change
onmessage - on message sent
onoffline - view offline page
ononline - view online page
onpagehide - on navigates away from web page
onpageshow - inverse of onpagehide
onpopstate - on browser history change
onresize - on browser resize
onstorage - on web storage updated
onscroll - on user scroll
onunload - on web page closed
