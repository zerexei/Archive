<?php

// import SimpleRouter
use \SimpleRouter\Router;
use \SimpleRouter\Request;


require __DIR__ . 'vendor/autoload.php';
