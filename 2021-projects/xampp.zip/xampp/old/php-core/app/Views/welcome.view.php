<?php includes('header') ?>

<h1>Welcome</h1>

<?php includes('footer') ?>