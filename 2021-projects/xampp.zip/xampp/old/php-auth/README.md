<h1 align="center">
  <a href="https://github.com/zerexei/">
    REET Auth
  </a>
</h1>

<p align="center">
    Simple authentication system
</p>

<p align="center">
  <a href="https://lbesson.mit-license.org/">
    <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="React Native is released under the MIT license." />
  </a>
  <a href="https://github.com/zerexei/">
    <img src="https://img.shields.io/badge/Version-1.0-blue.svg" alt="Current package version." />
  </a>
  <a href="#">
    <img src="https://img.shields.io/badge/Pull_Request-YES-blue.svg" alt="PRs welcome!" />
  </a>
</p>
