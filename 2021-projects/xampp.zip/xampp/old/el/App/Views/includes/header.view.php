<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $title ?? CONFIG['APP_NAME'] ?></title>


  <link rel="stylesheet" href="<?php echo assets('css/main.css') ?>">
  <script src="<?php echo assets('js/main.js') ?>" defer></script>
</head>

<body>
  <header>
    <div>
      <h1>Foo Bar</h1>
    </div>
    <div class="navbar">
      <nav>
        <a href="#">Welcome</a>
        <a href="#">Dashboard</a>
      </nav>
      <div>
        <a href="#">Login</a>
        <a href="#">Register</a>
      </div>
    </div>
  </header>
  <main>