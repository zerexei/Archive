<!-- TODO: create a function to add include files -->
<?php require 'App/Views/includes/header.view.php' ?>

<div class="containe">
  <h2>Register</h2>
  <form action="/el/register" method="POST">
    <?php echo csrf_field(); 
    var_dump($_SESSION);
    ?>
    <div>
      <label>Email</label>
      <input type="text" name="email">
    </div>
    <div>
      <label>Password</label>
      <input type="password" name="password">
    </div>
    <div>
      <label>Confirm Password</label>
      <input type="password" name="password_confirmation">
    </div>
    <div>
      <button type="submit">Register</button>
    </div>
  </form>
</div>

<?php require 'App/Views/includes/footer.view.php' ?>