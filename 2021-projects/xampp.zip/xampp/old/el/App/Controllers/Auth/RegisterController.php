<?php

namespace App\Controllers\Auth;

use App\Models\User;

class RegisterController
{
    public function register()
    {
        request()->validate([
            'email' => 'required',
            'password' => ''
        ])
    }
}
