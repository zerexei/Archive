<?php

$router->get('/', function () {
    return view('welcome');
});

$router->get('/register', fn () => view('auth.register'));
$router->post('/register', 'Auth\\RegisterController@register');
