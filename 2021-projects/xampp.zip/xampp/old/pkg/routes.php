<?php

$router->setHost('pkg');

// set routes
$router->get('/:int', function ($i) {
  exec("ls -a", $a);
  print_r($a);
});
