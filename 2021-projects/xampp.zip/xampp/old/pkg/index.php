<?php

use \SimpleRouter\Router;
use \SimpleRouter\Request;

require_once __DIR__ . '/vendor/autoload.php';

$router = Router::init();
require_once 'routes.php';
$router->run(Request::url(), Request::method());
