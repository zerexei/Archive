     <table>
      <th>Name</th>
      <th>Email</th>
      <th>Age</th>
      <th>Adress</th>
      <th>Course</th>
      <th>Status</th>
    <?php
    require_once '../router/view-router.php';
     ?>
   </table>
