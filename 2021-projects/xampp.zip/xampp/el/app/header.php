
<!DOCTYPE html>
<html lang="en" dir="ltr">

  <!-- /////////META TAGS/////////// -->
  <meta charset="UTF-8">
  <meta name="description" content"I am Evangel Laclairs a Freelance full stack web developer with specialty in back end development and cyber security. I got knowledge in SEO,UX,IU,Responsive Design,Optimized/Secured Website,Linux,Penetration
    testing and ethical hacking.">
    <!-- <meta name="keywords" content=""> -->
  <meta name="author" content"Evangel Laclairs">
  <link rel="shortcut icon" type="image/png" href="logo.png">
  <meta name="rating" content="general">
  <meta name="google" content="nositelinkssearchbox" />
  <meta name="google" content="notranslate" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <!-- ////////////STYLE//////////////// -->
  <link rel="stylesheet" href="../css/style.css">

  <title>Evangel Laclairs - Freelance Web Developer with specialty in back-end development and cyber security</title>
</head>

<body>
