<?php

// include database
require_once 'connect.php';

// register applicant for scholaship
if (isset($_POST['apply_scholarship'])) {
    // validate request

    $inputs = sanitize($_POST);
    if (!isset($inputs['first_name'])) return '';

    $fields = ['first_name', 'last_name', 'birth_date', 'current_address', 'phone_number', 'email_address', 'course', 'scholarship_type'];
    $columns = implode(",", $fields);
    $values = get_fields_placeholder($fields);
    $sql = "INSERT INTO scholarships ($columns) VALUES ($values)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(array_values($data));
    return header('location: index.php');
}

// fields to pdo prepared statement placeholder
function get_fields_placeholder(array $fields)
{
    // repeat question marks(?)
    $placeholders = str_repeat("?,", count($fields));
    // remove excess comma(,)
    return trim($placeholders, ",");
}

// sanitize all items
function sanitize(...$items)
{
    return array_map(function ($item) {
        return filter_var($item, FILTER_SANITIZE_STRING);
    }, $items);
}

// validate email
function is_valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// validate if empty
function is_empty(?string $item): bool
{
    if (is_null($item)) return false;
    $trimmed_item = trim($item);
    return strlen($trimmed_item)  <= 0;
}

// die and dump
function dd(...$data)
{
    echo "<pre>";
    die(var_dump($data));
    echo "</pre>";
}
