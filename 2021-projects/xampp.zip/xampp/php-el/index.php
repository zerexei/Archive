<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EL</title>
</head>

<style>
    #container {
        width: 50%;
        margin: 10vh auto;
    }
</style>

<body>
    <div id="container">
        <h1>HELLO WORLD!</h1>

        <form action="server.php" method="POST">
            <!-- FIRST NAME -->
            <div>
                <label for="first_name">First Name</label>
                <input type="text" name="first_name" />
            </div>
            <!-- LAST NAME -->
            <div>
                <label for="last_name">Last Name</label>
                <input type="text" name="last_name" />
            </div>

            <!-- BIRTH DATE -->
            <div>
                <label for="birth_date">Birth Date</label>
                <input type="date" name="birth_date">
            </div>

            <!-- CURRENT ADDRESS -->
            <div>
                <label for="current_address">Current Address</label>
                <input type="text" name="current_address" />
            </div>

            <!-- PHONE NUMBER -->
            <div>
                <label for="phone_number">Phone Number</label>
                <input type="text" name="phone_number" />
            </div>

            <!-- EMAIL ADDRESS -->
            <div>
                <label for="email_address">Email Address</label>
                <input type="email" name="email_address" />
            </div>

            <!-- COURSE -->
            <div>
                <label for="course">Course</label>
                <select name="course">
                    <option>BSCS</option>
                    <option>BSAB</option>
                    <option>BSCD</option>
                    <option>ABEF</option>
                    <option>BSN</option>
                    <option>BSE</option>
                    <option>BBBB</option>
                </select>
            </div>

            <!-- SCHOLARSHIP TYPE -->
            <div>
                <label for="scholarship_type">Scholarship Type</label>
                <select name="scholarship_type">
                    <option>25% Scholarship</option>
                    <option>Half Scholarship</option>
                    <option>Full Sholarship</option>
                </select>
            </div>

            <!-- LEGAL STUFF -->

            <div>
                <button name="apply_scholarship">Submit</button>
            </div>
        </form>
    </div>
</body>

</html>
<!-- 
        fields:
        first name
        last name
        birth date
        address
        email
        phone number
        course
        scholarship type
    -->