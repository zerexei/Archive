<?php

$config = require_once 'config.php';

try {
    $conn = new PDO(
        $config['connection'] . ';dbname=' . $config['name'],
        $config['username'],
        $config['password'],
        $config['options']
    );
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
