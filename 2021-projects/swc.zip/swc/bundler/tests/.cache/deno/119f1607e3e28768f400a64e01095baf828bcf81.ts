// Loaded from https://deno.land/x/abc@v1.2.4/vendor/https/deno.land/std/mime/multipart.ts


export * from "https://deno.land/std@0.81.0/mime/multipart.ts";
