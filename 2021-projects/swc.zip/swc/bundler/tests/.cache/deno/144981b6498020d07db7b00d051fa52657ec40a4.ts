// Loaded from https://deno.land/x/deno_image@v0.0.3/deps.ts


export { encode as encodeJPG, decode as decodeJPG, Image } from "https://deno.land/x/jpegts@1.1/mod.ts";
