// Loaded from https://deno.land/x/abc@v1.2.4/vendor/https/deno.land/std/fmt/colors.ts


export * from "https://deno.land/std@0.81.0/fmt/colors.ts";
