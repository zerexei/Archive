// Loaded from https://deno.land/x/type_is@1.0.1/deps.ts


export { lookup } from "https://deno.land/x/media_types/mod.ts";
export { parse } from "https://deno.land/x/content_type/mod.ts";
export { test } from "https://deno.land/x/media_typer/mod.ts";
