// Loaded from https://deno.land/x/ramda@v0.27.2/source/splitAt.js


import _curry2 from './internal/_curry2.js';
import length from './length.js';
import slice from './slice.js';


/**
 * Splits a given list or string at a given index.
 *
 * @func
 * @memberOf R
 * @since v0.19.0
 * @category List
 * @sig Number -> [a] -> [[a], [a]]
 * @sig Number -> String -> [String, String]
 * @param {Number} index The index where the array/string is split.
 * @param {Array|String} array The array/string to be split.
 * @return {Array}
 * @example
 *
 *      R.splitAt(1, [1, 2, 3]);          //=> [[1], [2, 3]]
 *      R.splitAt(5, 'hello world');      //=> ['hello', ' world']
 *      R.splitAt(-1, 'foobar');          //=> ['fooba', 'r']
 */
var splitAt = _curry2(function splitAt(index, array) {
  return [slice(0, index, array), slice(index, length(array), array)];
});
export default splitAt;
