// Loaded from https://deno.land/x/segno@v1.1.0/mod.ts


import * as segno from './lib/index.ts';

// exporting all functions
export * from './lib/index.ts';

// exporting functions namespaced to segno
export { segno };
