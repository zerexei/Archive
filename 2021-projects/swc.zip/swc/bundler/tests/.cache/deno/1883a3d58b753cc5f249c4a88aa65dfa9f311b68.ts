// Loaded from https://deno.land/x/media_types@v2.5.1/deps.ts


// Copyright 2020 the oak authors. All rights reserved. MIT license.

export { extname } from "https://deno.land/std@0.73.0/path/mod.ts";
