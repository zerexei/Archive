// Loaded from https://deno.land/x/mongo@v0.20.0/src/collection/mod.ts


export { Collection } from "./collection.ts";
