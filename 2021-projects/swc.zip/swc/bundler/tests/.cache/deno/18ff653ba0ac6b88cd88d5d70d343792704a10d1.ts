// Loaded from https://deno.land/x/ramda@v0.27.2/source/internal/_xfBase.js


export default {
  init: function() {
    return this.xf['@@transducer/init']();
  },
  result: function(result) {
    return this.xf['@@transducer/result'](result);
  }
};
