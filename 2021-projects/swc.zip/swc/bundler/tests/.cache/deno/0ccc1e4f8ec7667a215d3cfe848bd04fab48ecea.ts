// Loaded from https://deno.land/x/cliffy@v0.18.0/ansi/deps.ts


export {
  encode as encodeBase64,
} from "https://deno.land/std@0.89.0/encoding/base64.ts";
