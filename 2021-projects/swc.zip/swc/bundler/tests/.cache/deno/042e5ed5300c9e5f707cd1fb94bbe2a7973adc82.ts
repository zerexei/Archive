// Loaded from https://deno.land/x/ramda@v0.27.2/source/lensProp.js


import _curry1 from './internal/_curry1.js';
import assoc from './assoc.js';
import lens from './lens.js';
import prop from './prop.js';


/**
 * Returns a lens whose focus is the specified property.
 *
 * @func
 * @memberOf R
 * @since v0.14.0
 * @category Object
 * @typedefn Lens s a = Functor f => (a -> f a) -> s -> f s
 * @sig String -> Lens s a
 * @param {String} k
 * @return {Lens}
 * @see R.view, R.set, R.over
 * @example
 *
 *      const xLens = R.lensProp('x');
 *
 *      R.view(xLens, {x: 1, y: 2});            //=> 1
 *      R.set(xLens, 4, {x: 1, y: 2});          //=> {x: 4, y: 2}
 *      R.over(xLens, R.negate, {x: 1, y: 2});  //=> {x: -1, y: 2}
 */
var lensProp = _curry1(function lensProp(k) {
  return lens(prop(k), assoc(k));
});
export default lensProp;
