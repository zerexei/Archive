// Loaded from https://deno.land/x/bytes_formater@v1.4.0/mod.ts


export { format } from "./format.ts";
export { setColorEnabled } from "./deps.ts";
