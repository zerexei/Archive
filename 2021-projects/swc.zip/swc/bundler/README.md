# swc_bundler

Bundler for the swc project.

## Features

- Clean merging (generated code is easy to optimize)
- Parallel file loading
- Tree shaking
- Common js support (aka `require`)
- Circular imports

Tests live at `/spack`.
