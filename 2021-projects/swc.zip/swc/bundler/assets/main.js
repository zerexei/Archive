import { A, FOO } from './a';

console.log(A, FOO);