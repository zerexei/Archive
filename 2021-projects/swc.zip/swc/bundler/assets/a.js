export const FOO = 1;


export class A {
    foo() {
    }
}