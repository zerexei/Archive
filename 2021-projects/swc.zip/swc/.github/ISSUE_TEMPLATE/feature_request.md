---
name: Feature request
about: Use this when you want a new feature
title: ""
labels: ""
assignees: ""
---

<!--
If you are using swc at work, please considering adding your company to https://swc.rs/users/
If then, your issue will be fixed more quickly.
-->

**Describe the feature**

**Babel plugin or link to the feature description**

**Additional context**
Add any other context about the problem here.
