// Show who’s online.
// Add private messaging.
// Share your improvements!

import express from "express";
import http from "http";
import path from "path";
import { Server } from "socket.io";

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.get("/", (req, res) => {
	res.sendFile(path.resolve() + "/index.html");
});

let users = [];
io.on("connection", (socket) => {
	// set nickname
	socket.on("set username", (username) => {
		socket.username = username;

		// user connected
		io.emit("reet message", `${username} has connected`);

		// define user
		const user = {
			id: users.id,
			username: socket.username,
		};
		// set active user
		users.push(user);
		io.emit("active", users);
	});

	// user disconnected
	socket.on("disconnect", () => {
		// remove active user
		users = users.filter((user) => user.username !== socket.username);
		io.emit("active", users);

		io.emit("reet message", `${socket.username} has disconnected`);
	});

	// user message
	socket.on("reet message", (msg, id) => {
		io.emit("reet message", msg, id);
	});

	socket.on("typing", (user) => {
		io.emit("typing", user);
	});

	socket.on("private message", (anotherSocketId, msg) => {
		socket.to(anotherSocketId).emit("private message", socket.id, msg);
	});
});

server.listen(3001, () => {
	console.log("listening on *:3000");
});
