import express from "express";

const app = express();

// prisma client
import { PrismaClient, Prisma } from "@prisma/client";
const prisma = new PrismaClient();

// CREATE
app.get("/create", async (req, res) => {
	const user = await prisma.user.create({
		data: {
			email: "elsa@prisma.io",
		},
	});

	res.send(user);
});

// READ ALL
app.get("/", async (req, res) => {
	const users = await prisma.user.findMany();
	res.send(users);
});

// READ
app.get("/user", async (req, res) => {
	const user = await prisma.user.findUnique({
		where: {
			email: "viola@prisma.io",
		},
	});
	res.send(user);
});

// UPDATE
app.patch("/update", async (req, res) => {
	const updateUser = await prisma.user.update({
		where: {
			email: "elsa@prisma.io",
		},
		data: {
			email: "viola@prisma.io",
		},
	});
	res.send(updateUser);
});

app.delete("/delete", async (req, res) => {
	const deleteUser = await prisma.user.delete({
		where: {
			email: "viola@prisma.io",
		},
	});
	res.send(deleteUser);
});

app.listen(3001, () => console.log("Listening..."));
