import express from 'express'
const router = express.Router();

router.get("/", async (req: unknown, res: any) => {

  const reqWordList = await fetch(
    "https://raw.githubusercontent.com/words/an-array-of-english-words/master/index.json"
  );
  // word list
  const wordList = await reqWordList.json();
  // random word from word list
  const word = wordList[Math.floor(Math.random() * wordList.length)];
  // query selected word
  const response = await fetch(word);

  const dictionary = fetch(`https://www.dictionaryapi.com/api/v3/references/collegiate/json/${word}?key=${process.env.API_KEY}`)
  res.send(dictionary)
});

