# output
foo = "Hello"
bar = "World"

print('Hello, World!')
print(foo, bar, "!") # Hello World !

# change end of line behavior
print("alter end of line", end=" ")

# input
my_input = input()
print(my_input)

# python variables
foo = "String"
bar = 55
baz = True
