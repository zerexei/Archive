// currying - function programming
function number(integer) {
  return (operation) => (operation ? operation(integer) : integer);
}

// create functions | 0 to 9
["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",]
.forEach((key, index) => (this[key] = number(index)));

// operations
const plus = (right) => (left) => left + right;
const minus = (right) => (left) => left - right;
const times = (right) => (left) => left * right;
const divide = (right) => (left) => left / right;

console.log(one(plus(one()))); // 2
