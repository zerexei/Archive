def iq_test(numbers):
    # convert values to boolean
    e = [int(i) % 2 == 0 for i in numbers.split()]
    # ternary | count all true if 1 return index of true else index of false
    return e.index(True) + 1 if e.count(True) == 1 else e.index(False) + 1