# filter none int
def filter_list(l):
  return [i for i in l if not isinstance(i, str)]