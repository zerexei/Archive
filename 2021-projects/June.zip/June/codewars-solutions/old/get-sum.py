# sum of min to max
def get_sum(a,b):
    return sum(range(min(a, b), max(a, b) + 1))