<?php
function removeRotten($fruitBasket)
{
  return str_replace("rotten", "", array_map("strtolower", (array) $fruitBasket));
}
