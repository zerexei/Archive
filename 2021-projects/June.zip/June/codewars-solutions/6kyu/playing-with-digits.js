// best
function digPow(n, p) {
  var x = String(n).split("").reduce((s, d, i) => s + Math.pow(d, p + i), 0)
  return x % n ? -1 : x / n
}

// my solution
function digPow(n, p){
  // number -> string
  const digits = n.toString()
  
  // placeholder for sum of array
  let sum = 0;
  
  // loop through array
  for (let digit of digits) {
    // current array exponential p then add to sum
    sum += digit ** p;
    // sum += digit ** p++;
    
    // increment p
    p += 1;
  }
  
  // sum divided by number passed
  const result = sum/n;

  // check if integer or float
  return Number.isInteger(result) ? -1 : result
  // return sum % n  ? -1 : sum/n
}