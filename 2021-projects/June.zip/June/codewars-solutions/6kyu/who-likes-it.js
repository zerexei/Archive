// best solution
function likes(names) {
  names = names || [];
  switch(names.length){
    case 0: return 'no one likes this';
    case 1: return names[0] + ' likes this';
    case 2: return names[0] + ' and ' + names[1] + ' like this';
    case 3: return names[0] + ', ' + names[1] + ' and ' + names[2] + ' like this';
    default: return names[0] + ', ' + names[1] + ' and ' + (names.length - 2) + ' others like this';
  }
}

// my solution
function likes(names) {
  // check if names is not an array
  if (! Array.isArray(names)) return;

  // count array length
  const countNames = names.length;

  // check if array is empty
  const isEmptyNames = countNames === 0

  // check if no one like this
  if (isEmptyNames) return 'no one likes this'
  
  // check if someone like this
  if (countNames === 1) return `${names[0]} likes this`
  
  // check if two people like this
  if (countNames === 2) return `${names[0]} and ${names[1]} like this`
  
  // check if 3 people like this
  if (countNames === 3) return `${names[0]}, ${names[1]} and ${names[2]} like this`
  
  // return if above condition didn't met
  return `${names[0]}, ${names[1]} and ${countNames - 2} other like this`
}