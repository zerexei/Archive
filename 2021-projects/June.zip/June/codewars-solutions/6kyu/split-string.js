// using regex: clever tho
const solution = (str) => (str+"_").match(/../g)||[] // regex max 2 char

// my solution
function solution(str){
  if (str === '') return []
  
  const arr = str.split("");
  const lenArr = arr.length;
  
  let result = [[arr[0] + arr[1]].toString()];
    
  for (let i=3; i<=lenArr; i+=2) {
    if (arr[i] !== undefined) { 
      result.push([arr[i-1]+ arr[i]].toString())
    } else {
      result.push(arr[i-1].toString() + '_')
    }
  }
  
  return result
}