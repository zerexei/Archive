<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mb-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between">
                        <h2 class="mb-2 text-xl">{{$post->title}}</h2>
                        <div class="text-xs">
                            <a href="/posts/1/edit" class="text-blue-500">Edit</a>
                            <a href="#" class="ml-2 text-red-500">Delete</a>
                        </div>
                    </div>
                    <p class="mb-1 text-sm text-gray-900">
                        {{$post->body}}
                    </p>
                    <p class="text-xs text-gray-700">author: {{$post->user->name}}</p>
                </div>
            </div>
        </div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6">
                    <div class="mb-6">
                        <form action="#">
                            <textarea name="body" rows=3 class="w-1/2 p-2 border rounded"></textarea>
                            <button class="block py-2 px-4 mt-1 text-white bg-blue-400 rounded">Comment</button>
                        </form>
                    </div>

                    <div class="text-sm text-gray-900 flex flex-col gap-5">
                        <div>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illo aliquid aliquam,
                                repellendus cum perspiciatis quaerat officia, blanditiis ipsa et quisquam assumenda
                                placeat. Enim consectetur laborum soluta quia adipisci quidem corporis.</p>
                            <span>author: Admin 123</span>
                        </div>
                        <div>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illo aliquid aliquam,
                                repellendus cum perspiciatis quaerat officia, blanditiis ipsa et quisquam assumenda
                                placeat. Enim consectetur laborum soluta quia adipisci quidem corporis.</p>
                            <span>author: Admin 123</span>
                        </div>
                        <div>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illo aliquid aliquam,
                                repellendus cum perspiciatis quaerat officia, blanditiis ipsa et quisquam assumenda
                                placeat. Enim consectetur laborum soluta quia adipisci quidem corporis.</p>
                            <span>author: Admin 123</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
