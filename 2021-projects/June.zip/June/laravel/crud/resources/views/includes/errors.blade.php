@if ($errors->any())
<div class="p-2 mb-4 border-b border-red-200">
    <ul class="list-disc list-inside text-red-400 text-sm">
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif
