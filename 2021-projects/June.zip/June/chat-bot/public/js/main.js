// reference: https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition

// get speech recognition based on browser compatibility
const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;
// create speech recognition object
const recognition = new SpeechRecognition();

// set the language of the current SpeechRecognition
recognition.lang = "en-US";
// Interim results are results that are not yet final
recognition.interimResults = false;

// add click event to speak button
// then start recognition
document
  .querySelector("#speak")
  .addEventListener("click", () => recognition.start());

// recognition.addEventListener("result", (e) => {
recognition.onresult = (e) => {
  let last = e.results.length - 1;
  let text = e.results[last][0].transcript;
  console.log(`Confidence: ${e.results[0][0].confidence}`);
  console.log(`Result: ${text}`);

  if (text == "hello") {
    console.log("Howdy!");
  }
};
// });
async function request() {
  const projectId = "zing-gsmt";
  const sessionId = "test123";
  const data = {
    query_input: {
      text: {
        text: "I know french",
        language_code: "en-US",
      },
    },
  };

  const req = await fetch(
    `https://dialogflow.googleapis.com/v2/projects/${projectId}/agent/sessions/${sessionId}:detectIntent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    }
  );

  console.log(await req.json());
}
// console.log("wroing//");

// const socket = io();
// socket.emit("chat message", text);
