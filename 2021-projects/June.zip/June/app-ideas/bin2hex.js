// Binary Converter
const bin2int = (bin) => base(bin, 2); // integer
const bin2oct = (bin) => base(bin, 8); // octal
const bin2dec = (bin) => base(bin, 10); // decimal
const bin2hex = (bin) => base(bin, 16); // hexadecimal

// Octal Converter
const oct2int = (oct) => base(oct, 8); // integer
const oct2bin = (oct) => base(oct, 2); // binary
const oct2dec = (oct) => base(oct, 10); // decimal
const oct2hex = (oct) => base(oct, 16); // hexadecimal

// Decimal Converter
const dec2int = (dec) => base(dec, 10); // integer
const dec2bin = (dec) => base(dec, 2); // binary
const dec2oct = (dec) => base(dec, 8); // octal
const dec2hex = (dec) => base(dec, 16); // hexadecimal

// Hexadecimal Converter
const hex2int = (hex) => base(hex, 16); // integer
const hex2bin = (hex) => base(hex, 2); // binary
const hex2oct = (hex) => base(hex, 8); // octal
const hex2dec = (hex) => base(hex, 10); // decimal

function base(n, base = 2) {
  return Number.parseInt(n, base);
}

// Integer Converter
const int2bin = (int) => int.toString(2); // binary
const int2oct = (int) => int.toString(8); // octal
const int2dec = (int) => int.toString(10); // decimal
const int2hex = (int) => int.toString(16); // hexadecimal
