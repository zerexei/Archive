<?php
// set host url
$router->host = 'php-core';

// set route
$router->get('/', function () {
  return view('welcome');
});
