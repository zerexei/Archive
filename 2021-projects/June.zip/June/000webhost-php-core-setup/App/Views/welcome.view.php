<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php assets('css/main.css') ?>">

    <!-- Scripts -->
    <script src="<?php echo assets('js/main.js') ?>" defer></script>
</head>

<body>
    <header>
        <!-- Header -->
        <nav>
            <a href="#">Home</a>
            <a href="#">Users</a>
            <a href="#">About</a>
        </nav>
    </header>
    <main>
        <div class="container">
            <!-- Main content -->

        </div>
    </main>
    <footer>
        <!-- Footer -->
    </footer>
</body>

</html>