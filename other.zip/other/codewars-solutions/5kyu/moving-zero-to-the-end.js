// best - changed to es6
var moveZeros = function (arr) {
  return arr.filter((x) =>  x !== 0).concat(arr.filter((x) => x === 0));
}

// my solution
var moveZeros = function (arr) {
  let zeros = 0;

  // remove zeros
  const filtered = arr.filter((item) => {
    if (item === 0) {
      zeros += 1;
      return false;
    }

    return true;
  });

  // add zeros
  for (i = 0; i < zeros; i++) {
    filtered.push(0);
  }

  return filtered;
};
