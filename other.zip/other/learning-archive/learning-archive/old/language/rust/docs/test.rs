assert_eq!("from", "to"); // asserts that two expressions are equal
assert_ne!("from", "to"); // asserts that two expressions are not equal