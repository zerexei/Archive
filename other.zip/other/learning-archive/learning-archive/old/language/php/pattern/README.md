# Implementation of Design Pattern and Clean Code

source: [Design Pattern](https://sourcemaking.com)