# Testing

# Functional Testing
- Test all the links
- Test all the forms
- cookies testing
- validate html/css
- database testing

Links
1. Internal Links
2. External Links
3. Mail Links
4. Broken Links

Forms
1. Field validation
2. Error message for wrong input
3. Optional and Mandatory fields

Database
- Testing will be done on database integrity.

# Usablility Testing
- Ease of learning
- Navigation
- Subjective user satisfaction
- General appearance

**included**
- The website should be easy to use.
- The instructions provided should be very clear.
- Check if the instructions provided are perfect to satisfy its purpose.
- The main menu should be provided on each page.
- It should be consistent enough.

**Content Checking**
- logical and understandable
- error free spelling
- discouragement of using dark colors
- 







compatibility testing
