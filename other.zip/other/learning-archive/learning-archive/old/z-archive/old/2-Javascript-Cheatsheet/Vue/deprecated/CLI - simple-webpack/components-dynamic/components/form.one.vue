<template lang="html">
  <div class="">
    <h2>form-1</h2>
    <textarea name="name" rows="8" cols="80"></textarea>
  </div>
</template>