
  <template>
    <div>
<add-app></add-app>
    </div>
  </template>

  <script>
  import Add from './components/add.blog.vue'
export default {
  components:{
    'add-app':Add
  },
  data() {

    return {
    }
  }
    }
</script>

<style scoped>
</style>
