package com.example.greetingcard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.greetingcard.ui.theme.HappyBirthdayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HappyBirthdayTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    BirthdayGreetingWithImage(
                        message = getString(R.string.happy_birthday_message),
                        from = getString(R.string.signature_text)
                    )
                }
            }
        }
    }
}


// @Composable: pascal-case functions
@Preview(showBackground = true)
@Composable
fun BirthdayCardPreview() {
    HappyBirthdayTheme {
        BusinessCard()
    }
}

@Composable
fun BirthdayGreetingWithText(
    message: String = "Happy Birthday",
    from: String
): Unit {

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        // too much characters: uses full width
        Text(
            text = message,
            fontSize = 36.sp,
            modifier = Modifier
                .padding(start = 16.dp, top = 16.dp),
            textAlign = TextAlign.Center,
        )

        Text(
            text = from,
            fontSize = 24.sp,
            modifier = Modifier
                .padding(start = 16.dp, end = 16.dp)
        )
    }
}

@Composable
fun BirthdayGreetingWithImage(
    message: String = "Happy Birthday John",
    from: String = "Smith",
) {
    val image = painterResource(R.drawable.androidparty);


    Box {
        Image(
            painter = image,
            contentDescription = "birthday cake image",
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(),
            contentScale = ContentScale.Crop
        )

        BirthdayGreetingWithText(message, from)
    }
}

@Composable
fun ComposeArticle() {
    val image = painterResource(R.drawable.androidparty);
    Column {

        Column {
            Image(
                painter = image,
                contentDescription = "birthday cake image",
                modifier = Modifier
                    .height(100.dp)
                    .fillMaxWidth(),
                contentScale = ContentScale.Crop
            )
        }
        Column {
            Text(
                text = stringResource(R.string.article_title),
                fontSize = 24.sp,
                modifier = Modifier.padding(16.dp)
            )

            Text(
                text = "Jetpack Compose is a modern toolkit for building native Android UI. Compose simplifies and accelerates UI development on Android with less code, powerful tools, and intuitive Kotlin APIs.",
                modifier = Modifier.padding(start = 16.dp, end = 16.dp),
                textAlign = TextAlign.Justify
            )

            Text(
                text = "In this tutorial, you build a simple UI component with declarative functions. You call Compose functions to say what elements you want and the Compose compiler does the rest. Compose is built around Composable functions. These functions let you define your app\\'s UI programmatically because they let you describe how it should look and provide data dependencies, rather than focus on the process of the UI\\'s construction, such as initializing an element and then attaching it to a parent. To create a Composable function, you add the @Composable annotation to the function name.",
                modifier = Modifier.padding(16.dp),
                textAlign = TextAlign.Justify
            )
        }
    }
}

@Composable
fun Quadrant() {
    val image = painterResource(R.drawable.androidparty);
    Column {

        Row {
            Text(
                text = "Upper Left",
                Modifier
                    .width(100.dp)
                    .height(100.dp)
                    .background(color = Color.Red)
            )

            Image(
                painter = image,
                contentDescription = "birthday cake image",
                modifier = Modifier
                    .width(100.dp)
                    .height(100.dp),
                contentScale = ContentScale.Crop
            )
        }
        Row {

            Row(
                Modifier
                    .width(100.dp)
                    .height(100.dp)
                    .background(color = Color.Yellow)
            ) {

            }
            Column(
                Modifier
                    .width(100.dp)
                    .height(100.dp)
                    .background(color = Color.Green)
            ) {

            }
        }
    }
}

@Composable
fun CenterCenter() {
    Box(
        Modifier
            .height(500.dp)
            .width(300.dp), contentAlignment = Alignment.Center
    ) {
        Row(
            Modifier
                .width(100.dp)
                .height(100.dp)
                .background(color = Color.Yellow)
        ) {
        }
    }
}

@Composable
fun BusinessCard() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Spacer(Modifier.weight(1f))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(modifier = Modifier.background(color = Color.Red))
            Text(text = "Full Name") // modifiers for size/weight
            Text(text = "Title")
        }

        Spacer(Modifier.weight(1f)) // weight?? not width
        BusinessCardInfo()
        BusinessCardInfo()
        BusinessCardInfo()
    }
}

@Composable
fun BusinessCardInfo() {
    Row(
        modifier = Modifier.padding(start = 50.dp, end = 75.dp).fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(Icons.Rounded.Menu, contentDescription = "Localized description")
        Text(text = "+00 (00) 000 000") // modifiers for size/weight
    }
}