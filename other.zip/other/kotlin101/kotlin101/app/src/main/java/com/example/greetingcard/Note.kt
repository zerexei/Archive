function main () {

}

// single expression function definition
fun getGreeting(): String = "Hello World!";

// !# ARRAY/LIST
// val itemsArray = listOf("a", "b", "c");
val itemsArray = arrayOf("a", "b", "c");

// access array by index
println(itemsArray[0]) // a
println(itemsArray.get(2)) // c

// loop through itemsArray
for (item in itemsArray) {
    print(item)
}

itemsArray.forEach {item -> print(item)}
itemsArray.forEachIndexed {index, item -> print("$index => $item")}

// !# MAP
val itemsMap = mapOf(1 to "a", 2 to "b", 3 to "c");

// mutable collection
val itemsList = mutableListOf("a", "b", "c");
val itemsMap = mutableMapOf(1 to "a", 2 to "b", 3 to "c");


// "vararg" keyword similar to fun greet(a,...items) {}
fun greet(param1:String, vararg items:String) {}


// !# CLASS
class Person() {
var first_name: String? = null
    set(value) {
        field = value + "Added"
    }
    get() {
        return field + "Added Again"
    }

init  {
    this.first_name  = "bar"
  }
}

fun main() {
    val person = Person();
    person.first_name = "foo"
    print(person.first_name)
    
}


// more classes (access w/out this.)
class Person (val firstName: String, val lastName: String) {
    var nickName: String? = null;

    fun printInfo(): Unit {
        testWhyNotThis()
        val nickNameToPrint: String = nickName ?: "none";
        println("$firstName ($nickNameToPrint) $lastName");
    }

    fun testWhyNotThis() {
        println("What's the difference of [this.]")
    }
}


// interface
interface PersonInterface {
    val firstName: String;
    val age: Int;

    // fun printInfo();
    fun printInfo() {
        println("Print info from interface")
    }
}

class Person: PersonInterface {
    val firstName: String = "John";
    val age: Int = 111;

    fun printInfo() {
        super.printInfo(); 
        println("Print info from class");
    }
}
