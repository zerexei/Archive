export function add(x: number, y: number): number {
  return x + y;
}

export function multiply(a: number, b: number): number {
  return a * b;
}
