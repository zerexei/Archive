```php
is_string()
is_int()
is_float()
is_bool()
is_array()
is_object()
is_null()

is_callable()
is_countable()
is_iterable()
is_numeric()
is_resource()
is_scalar()

is_dir()
is_executable()
is_file()
is_link()
is_readable()
is_uploaded_file()
is_writable()

isset()
empty()
```