&#34; &quot; Quotation Marks - "
&#38; &amp; Ampersand - &
&#60; &lt; Less than sign - <
&#62; &gt; Greater than sign - >
&#160; &nbsp; Non-breaking space 
&#169; &copy; Copyright Symbol - ©
&#64; &Uuml; @ symbol - @
&#149; &ouml; Small bullet - .
&#153; &ucirc; Trademark Symbol - ™


 * sm: min-width: 640px;
 * md: min-width: 768px;
 * lg: min-width: 1024px;
 * xl: min-width: 1280px;

 [ FLEXBOX ]
justify-content - X axis
align-items - Y axis
align-content - Y axis gap
flex-direction
flex-wrap
flex - grow shrink basis
flex-basis - width


\2713 - check
\2714 - b-check
\2717 - X
\2718 - b-X
\275B - 1 qoute
\275C - 2 qoute
\275D - b-1 qoute
\275E - b-2 qoute
\275F
\2760
\2206 - increment
\2207 - decrement
\25B2 - b-inc
\25BC - b-dec


 [ CSS ] -coding standard

// Declaration order
Positioning
Box model
Typography
Visual
Misc

// Media query placement
Place media queries as close to their relevant rule sets whenever possible.

// Prefixed properties
Indent each property such that the declaration's value lines up vertically for easy multi-line editing.
