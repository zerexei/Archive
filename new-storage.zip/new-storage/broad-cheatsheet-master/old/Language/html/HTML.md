<details>
<summary>Semantic</summary>

```cs
[ header ] - 
[ nav ] - 
[ main ] - 
[ article ] - 
[ section ] - 
[ aside ] - 
[ figure ] - 
[ figcaption ] - 
[ details ] - 
[ summary ] - 
[ footer ] - 
```
</details>