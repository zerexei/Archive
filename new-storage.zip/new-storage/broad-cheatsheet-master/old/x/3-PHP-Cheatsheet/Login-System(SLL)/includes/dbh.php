<?php
$server = "localhost";
$user = "root";
$pwd = "";
$db = "loginsystem";

$conn = mysqli_connect($server,$user,$pwd,$db);

/*
loginsystem
-users
u_id int 11
u_first varchar 255
u_last varchar 255
u_email varchar 255
u_uid varchar 255
u_pwd varchar 255
*/
