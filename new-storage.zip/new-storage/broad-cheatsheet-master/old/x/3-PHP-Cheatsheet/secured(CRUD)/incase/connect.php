<?php
$user = "root";
$pwd = "";
$db = "test";

$conn = mysqli_connect("localhost", "$user", "$pwd", "$db"); //-> or only this $conn = mysqli_connect('localhost', 'root' , '', 'test');

?>
