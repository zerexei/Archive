<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

<!-- INSERT -->
<form action="server.php" method="post">
		<div>
		<label>Name:</label>
		<input type="text" name="name" placeholder="Your Name" required>
		<label>Age:</label>
		<input type="text" name="age" placeholder="Your Age" required>
		<label>E-mail</label>
		<input type="email" name="addr" placeholder="Your E-mail Address" required>
		<label>Phone:</label>
		<input type="text" name="phone" placeholder="Your Contact Number" required>
	</div>
<div>
	<button class="form-button" type="submit" name="save">Confirm</button>

</div></form><br>

<!-- DELETE -->

<!--UPDATE -->

</body>
</html>
