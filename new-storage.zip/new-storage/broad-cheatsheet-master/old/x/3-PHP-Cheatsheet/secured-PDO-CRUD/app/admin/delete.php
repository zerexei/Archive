
    <form class="" action="../router/delete-router.php" method="post">
      <select class="" name="reg_id">
        <?php
        require_once '../router/delete-router.php';
         ?>
      </select>
      <button type="submit" name="del">delete</button>
    </form>
