<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="calc.php" method="post">
      <input type="text" name="num1" >
      <input type="text" name="num2" >
      <select class="" name="calc">
        <option value="add">+</option>
        <option value="sub">-</option>
        <option value="mul">*</option>
      </select>
      <button type="submit">Compute</button>
    </form>
  </body>
</html>
