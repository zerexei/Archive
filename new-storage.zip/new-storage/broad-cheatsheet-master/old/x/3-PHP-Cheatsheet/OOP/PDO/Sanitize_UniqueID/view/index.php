<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>WELCOME</h1>
    <form class="" action="../model/account.php" method="post">
      <input type="text" name="name">
      <button type="submit" name="save">save</button>
    </form>
  </body>
</html>
