
<!DOCTYPE html>
<html>
<head>
	<title>Document</title>
</head>
<body>
	<form class="" action="users.php" method="post">
		<input type="text" name="uName" placeholder="username">
		<input type="text" name="uMail" placeholder="email">
		<input type="text" name="uPwd" placeholder="password">
		<button type="submit" name="save">Save</button>
	</form>
	<br>
	<form class="" action="users.php" method="post">
			<input type="text" name="uID" placeholder="ID">

			<button type="submit" name="del">Delete</button>
	</form>
	<br>
	<form class="" action="users.php" method="post">
		<input type="text" name="uID" placeholder="ID">
		<input type="text" name="uName" placeholder="username">
		<input type="text" name="uMail" placeholder="email">
		<input type="text" name="uPwd" placeholder="password">
		<button type="submit" name="update">Update</button>
	</form>
	<br>
</body>
</html>
