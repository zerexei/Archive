<?php

class newClass extends parentClass
  {
      //properties & Methods
      public function name(){
        return $this -> data;
      }
  }
 ?>
