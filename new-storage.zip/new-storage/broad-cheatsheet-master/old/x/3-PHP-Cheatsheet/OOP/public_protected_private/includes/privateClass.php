<?php

class privClass
{
  private $name = "Hi there!";

  public function name(){
    return $this -> name;
}
}
 ?>
