<?php

class parentClass {
  protected $data = "asd";
}

 ?>
