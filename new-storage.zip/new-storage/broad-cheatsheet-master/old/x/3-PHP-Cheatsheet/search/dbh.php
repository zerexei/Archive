<?php
$server ="localhost";
$user =  "root";
$pwd = "";
$db = "search";

$conn = mysqli_connect($server, $user, $pwd, $db);

/*
-article
a_id int(11) auto-incr
a_title varchar(255)
a_text text
a_autor varchar(255)
a_date datetime
*/
 ?>
