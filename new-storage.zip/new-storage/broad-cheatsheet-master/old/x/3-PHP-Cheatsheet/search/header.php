<?php
include "dbh.php";
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
<!-- add metadata for device width-->
    <meta charset="utf-8">

    <link rel="stylesheet" href="style.css">

    <title>Search</title>
  </head>
