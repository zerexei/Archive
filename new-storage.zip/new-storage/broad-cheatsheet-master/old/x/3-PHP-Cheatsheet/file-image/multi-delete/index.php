<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="delete.php" method="post">
      <!-- or type textbox -->
      <input type="text" name="filename" placeholder="separate each name with a comma (,)">
      <button type="submit" name="del">Delete</button>
    </form>
  </body>
</html>
