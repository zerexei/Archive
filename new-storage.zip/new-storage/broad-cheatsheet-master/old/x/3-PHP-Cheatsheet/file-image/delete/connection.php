<?php

$conn = mysqli_connect("localhost","root","","profile")


/*
Database

-user
id int(11)
first varchar(255)
last  varchar(255)
Username varchar(255)
password varchar(255)

-profileImg
id
userid
status 
*/

 ?>
