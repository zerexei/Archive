<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>images-files</title>
</head>
<body>
  <!--enctype="multipart/form-data" = used for image/other files -->
  <form class="" action="upload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="file" value="">
    <button type="submit" name="save">Upload</button>
  </form>
</body>
</html>
