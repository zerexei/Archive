<?php
json_encode($json);
json_decode($json);