<?php
//useful for performance testing
$time_start = microtime(true);
  // php code here
$time_end = microtime(true);
$ellapse_time = $time_end - $time_start;