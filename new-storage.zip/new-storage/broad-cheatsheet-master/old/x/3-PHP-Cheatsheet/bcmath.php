<?php

// base conversion function
base_convert()
bindec()
octdec()
hexdec()


NUMBER FUNCTION
abs - absolute value
ceil - round up
floot - round down
fmod - floating point remider of division
intdiv - integer devision
is_finite - finite number
is_infinite - infinite number
min - min number
max - max number
pi - float approximation of pi
rand - random number
sqrt - square root

LOGARITHMIC FUNCTION
exp - exponent of e
expm1 - exp minus 1
log - logarithm
log10 - base 10 logarithm
log1p - log(1 + number)
pow - base raised to a power

TRIGONOMETRIC FUNCTION
acos - arc cosine
asin - arc sine
atan - arc tangent
cos - cosine
sin - sine
tan - tangent
deg2rad - radian value of degree
rad2deg - degree value of radian
hypot - length of the hypotenuse of the right angle

HYPERBOLIC FUNCTION
acosh - inverse hyperbolic cosine
asinh - inverse hyperbolic sine
atanh - inverse hyperbolic tangent
cosh - hyperbolic cosine
sinh - hyperbolic sine
tanh - hyperbolic tangent
