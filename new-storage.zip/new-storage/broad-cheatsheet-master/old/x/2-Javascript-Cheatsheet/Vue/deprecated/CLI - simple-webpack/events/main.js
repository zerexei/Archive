import Vue from 'vue'
import App from './App.vue'

new Vue({
  //select id app from index
  el: '#app',
  //render from object App
  render: h => h(App)
})
