<template lang="html">
  <div id="slot">
    <!-- slot - placeholder<slot
         name="key"></slot> -->
    <slot name="form-header"></slot>
    <slot name="form-inputs"></slot>
    <slot name="form-controls"></slot>
    <slot name="form-links"></slot>
  </div>
</template>
