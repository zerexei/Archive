if (screen.width > 1223) {
  let element = document.createElement("script");
  element.src = "assets/js/main.js";
  document.body.appendChild(element);
}
