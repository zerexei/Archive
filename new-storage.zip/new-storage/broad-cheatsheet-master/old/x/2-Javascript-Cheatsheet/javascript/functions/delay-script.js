 <script>
window.onload = function () {
  let element = document.createElement("script");
  element.src = "myScript.js";
  document.body.appendChild(element);
};
</script>

// v2
<script src="script.js" defer></script>
