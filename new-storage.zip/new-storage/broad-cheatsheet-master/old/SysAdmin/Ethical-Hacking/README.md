**Web hacking**
<details>
<summary>email spoofing</summary>

```cs
[ SPF ] - Sender Policy Framework
[ DKIM ] - Domain Key Identified Mail
[ DMARC ] -  Domain-based Message Authentication, Reporting & Conformance
```
</details>
<details>
<summary>Application hacking</summary>

</details>
<details>
<summary>Reverse engineering</summary>

</details>
<details>
<summary>Social engineering</summary>

</details>
<details>
<summary>Tools</summary>

</details>