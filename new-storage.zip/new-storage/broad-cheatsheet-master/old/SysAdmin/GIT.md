```cs
[ git add -A ]                            // add all
[ git commit -m "<message>" ]             // commit w/ message
[ git push origin <branch> ]              // push branch to origin
[ git checkout -b <branch> ]              // create and goto new branch
[ git checkout master ]                   // goto master
[ git merge <branch> ]                    // merge branch to master
```