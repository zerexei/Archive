# Ttitle

## Table of Contents
- [name](link)



**delete all node_modules from computer** 
find . -name "node_modules" -type d -prune -print | xargs du -chs
