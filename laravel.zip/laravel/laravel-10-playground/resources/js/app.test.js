import { expect, it } from "vitest";

it("return true", () => {
    expect(true).toBe(true);
});
