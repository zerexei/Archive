<?php

namespace Database\Seeders;

use App\Models\Comment;
use App\Models\Post;
use App\Models\User;
use Database\Factories\CommentFactory;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

        User::factory()->count(15)->hasPosts(8)->create();
        // \App\Models\User::factory(10)->create();

        $this->call([
            // PostSeeder::class,
            CommentSeeder::class
        ]);
    }
}
