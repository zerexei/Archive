# DROPPED FOUND A SIMILAR OLD PROJECT


https://github.com/zerexei/Laravel-Blog







append to .env
```
SWEET_ALERT_AUTO_DISPLAY_ERROR_MESSAGES=true
SWEET_ALERT_ALWAYS_LOAD_JS=true
```
