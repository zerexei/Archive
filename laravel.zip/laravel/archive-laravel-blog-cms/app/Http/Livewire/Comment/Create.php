<?php

namespace App\Http\Livewire\Comment;

use Livewire\Component;

use App\Models\Post;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;

class Create extends Component
{

    public Post $post;
    public $comment;

    protected $rules = [
        'comment' => 'required'
    ];


    public function mount(Post $post)
    {
        $this->post = $post;
    }

    /**
     * Comment to a post
     */
    public function store()
    {
        $this->validate();

        $this->post->comments()->create([
            'body' => $this->comment,
            'user_id' => Auth::id()
        ]);

        $this->emit('refresh-comment');

        $this->comment = '';
    }

    public function render()
    {
        return view('livewire.comment.create');
    }
}
