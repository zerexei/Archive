<?php

namespace App\Http\Livewire\Comment;

use App\Models\Comment;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Livewire\Component;

class Show extends Component
{
    use AuthorizesRequests;

    protected $listeners = ['delete-comment' => 'destroy'];

    public Comment $comment;
    public $user_name;
    public $comment_body;
    public $isEdit = false;


    public function mount(Comment $comment)
    {
        $this->comment = $comment;
        $this->user_name = $comment->user->name;
        $this->comment_body = $comment->body;
    }

    public function update()
    {
        $this->validate([
            'comment_body' => ['required']
        ]);

        $this->authorize('update-comment', $this->comment);

        $this->comment->update([
            'body' => $this->comment_body
        ]);

        $this->toggleEditOption();
        $this->dispatchBrowserEvent('swal:update-comment', [
            'icon' => 'success',
            'title' => 'Success!',
            'text' => 'Comment updated successfuly.',
        ]);
        $this->emitUp('refresh-comment');
    }

    //! FIXME: incorrect comment id (changes too fast)
    public function destroy()
    {
        $this->authorize('delete-comment', $this->comment);
        $this->comment->delete();
        $this->emitUp('refresh-comment');
    }

    public function toggleEditOption()
    {
        $this->isEdit = !$this->isEdit;
    }

    public function showConfirmDelete()
    {
        $this->dispatchBrowserEvent('swal:delete-comment', [
            'icon' => 'error',
            'title' => 'Delete comment',
            'text' => 'Are you sure you want to delete this comment?',
            'showConfirmButton' => true,
            'showCancelButton' => true,
            'focusCancel' => true
        ]);
    }

    public function render()
    {
        return view('livewire.comment.show');
    }
}
