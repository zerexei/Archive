<?php

namespace App\Http\Controllers;

use App\Http\Requests\PostRequest;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use RealRashid\SweetAlert\Facades\Alert;

class PostController extends Controller
{
    // Use Alert;
    /**
     * Show all posts
     */
    public function index()
    {
        return view('posts.index', [
            'posts' => Post::with('comments')->latest()->paginate(20)
        ]);
    }

    /**
     * Show create post view
     */
    public function create()
    {
        return view('posts.create');
    }

    /**
     * Store a post
     */
    public function store(PostRequest $request)
    {
        $validatedData = $request->validated();
        $validatedData['author_id'] = Auth::id();

        Post::create($validatedData);

        return redirect('/posts')->with('success', 'Post successfuly created.');
    }

    /**
     * Show a post
     */
    public function show(Post $post)
    {
        return view('posts.show', compact('post'));
    }

    /**
     * Show edit post view
     */
    public function edit(Post $post)
    {
        $this->authorize('update', $post);
        return view('posts.edit', compact('post'));
    }

    /**
     * Update a post
     */
    public function update(PostRequest $request, Post $post)
    {
        $this->authorize('update', $post);

        $validatedData = $request->validated();
        $validatedData['author_id'] = Auth::id();

        $post->update($validatedData);

        return redirect('/posts')->with('success', 'Post updated successfuly');
    }

    /**
     * Delete a post
     */
    public function destroy(Post $post)
    {
        $this->authorize('delete', $post);

        $post->delete();
        return redirect('/posts')->with('success', "Post deleted successfuly");
    }
}
