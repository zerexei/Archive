<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class Post extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'body', 'author_id'];

    /**
     * Post has one user relationship
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'author_id', 'id');
    }

    /**
     * Post has many comment relationship
     */
    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function getCreatedAtAttribute()
    {
        $createdAt = $this->attributes['created_at'];
        return Carbon::parse($createdAt)->diffForHumans();
    }

    public function getAuthorNameAttribute()
    {
        return $this->user->email;
    }
}
