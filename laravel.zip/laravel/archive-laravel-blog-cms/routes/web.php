<?php

use App\Http\Controllers\CommentController;
use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;
use RealRashid\SweetAlert\Facades\Alert;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//? resourceful routes
// GET 	        /photos 	            index 	    photos.index
// GET 	        /photos/create      	create  	photos.create
// POST 	    /photos             	store 	    photos.store
// GET 	        /photos/{photo}     	show     	photos.show
// GET 	        /photos/{photo}/edit 	edit     	photos.edit
// PUT/PATCH 	/photos/{photo}      	update   	photos.update
// DELETE 	    /photos/{photo}      	destroy 	photos.destroy

Route::get('/', function () {
    return view('welcome');
});

Route::get('/posts', [PostController::class, 'index'])->name('posts.index');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::resource('posts', PostController::class)->except('index');
    Route::resource('posts.comments', CommentController::class)->only(['store', 'update', 'destroy']);
});

require __DIR__ . '/auth.php';
