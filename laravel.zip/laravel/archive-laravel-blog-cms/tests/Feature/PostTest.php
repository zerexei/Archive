<?php

namespace Tests\Feature;

use App\Models\Post;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;


class PostTest extends TestCase
{

    use RefreshDatabase;
    use WithFaker;

    public function test_can_redirect_to_all_posts()
    {
        $response = $this->get('/posts');
        $response->assertOk();
        $response->assertViewIs('posts.index');
    }

    /**
     * ========================= CREATE ======================
     */
    public function test_can_redirect_to_create_post()
    {
        $user = User::factory()->create();
        $response = $this->actingAs($user)->get('/posts/create');
        $response->assertOk();
        $response->assertViewIs('posts.create');
    }

    public function test_can_create_a_post()
    {
        $user = User::factory()->create();
        $data = [
            'title' => $this->faker()->sentence(),
            'body' => $this->faker()->paragraph()
        ];

        $response = $this->actingAs($user)->post('/posts', $data);
        $response->assertSessionHas('success');

        $this->assertAuthenticatedAs($user);
        $this->assertDatabaseCount('posts', 1);
        $this->assertDatabaseHas('posts', $data);
    }

    public function test_redirect_to_all_posts_after_post_is_created()
    {
        $user = User::factory()->create();
        $data = [
            'title' => $this->faker()->sentence(),
            'body' => $this->faker()->paragraph()
        ];

        $response = $this->actingAs($user)->post('/posts', $data);
        $this->assertAuthenticatedAs($user);
        $response->assertRedirect('/posts');
    }

    public function test_not_authenticated_user_cant_redirect_to_create_post()
    {
        $response = $this->get('/posts/create');
        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_not_authenticated_user_cant_create_a_post()
    {
        $data = [
            'title' => $this->faker()->sentence(),
            'body' => $this->faker()->paragraph()
        ];
        $response = $this->post('/posts', $data);
        $response->assertStatus(302);
        $response->assertRedirect('/login');

        $this->assertDatabaseCount('posts', 0);
        $this->assertDatabaseMissing('posts', $data);
    }

    /**
     * ========================= UPDATE ======================
     */
    public function test_can_redirect_to_edit_post()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();

        $response = $this->actingAs($user)->get("/posts/{$post->id}/edit");
        $response->assertStatus(200);
        $response->assertViewIs('posts.edit');

        $this->assertAuthenticatedAs($user);
    }

    public function test_can_update_a_post()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();

        $data = [
            'title' => 'updated title',
            'body' => 'updated body'
        ];

        $this->actingAs($user)->put("/posts/{$post->id}", $data);
        $this->assertDatabaseHas('posts', $data);
    }

    public function test_redirect_to_all_post_after_post_is_updated()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();

        $data = [
            'title' => 'updated title',
            'body' => 'updated body'
        ];

        $response = $this->actingAs($user)->put("/posts/{$post->id}", $data);
        $response->assertStatus(302);
        $response->assertRedirect('/posts');
        $response->assertSessionHas('success');
    }

    public function test_not_authenticated_user_cant_redirect_to_edit_post()
    {
        $response = $this->get('/posts/1/edit');
        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_not_authenticated_user_cant_update_a_post()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();

        $data = [
            'title' => 'updated title',
            'body' => 'updated body'
        ];

        $response = $this->put("/posts/{$post->id}", $data);
        $response->assertStatus(302);
        $response->assertRedirect('/login');

        $this->assertDatabaseMissing('posts', $data);
    }

    /**
     * ========================= DELETE ======================
     */
    public function test_can_delete_a_post()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();
        $data = [
            'title' => $post->title,
            'body' => $post->body
        ];

        $this->assertDatabaseCount('posts', 1);
        $this->actingAs($user)->delete("/posts/{$post->id}");
        $this->assertDatabaseCount('posts', 0);
        $this->assertDatabaseMissing('posts', $data);
    }

    public function test_redirect_to_all_post_after_posts_is_deleted()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();

        $response = $this->actingAs($user)->delete("/posts/{$post->id}");
        $response->assertRedirect('/posts');
        $response->assertSessionHas('success');
    }

    public function test_not_authenticated_user_cant_delete_a_post()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();

        $data = [
            'title' => $post->title,
            'body' => $post->body
        ];

        $response = $this->delete("/posts/{$post->id}");
        $response->assertStatus(302);
        $response->assertRedirect('/login');

        $this->assertDatabaseHas('posts', $data);
    }

    /**
     * ========================= FORM VALIDATIONS ======================
     */
    // TODO: research HOW TO VALIDATE FORM VALIDATION :sob:
    public function test_session_has_title_input()
    {
        $user = User::factory()->create();

        $data = [
            'title' => 'something'
        ];

        $response = $this->actingAs($user)->post('/posts', $data);
        $response->assertSessionHasInput('title', 'something');
    }

    public function test_session_has_body_input()
    {
        $user = User::factory()->create();

        $data = [
            'body' => 'something'
        ];

        $response = $this->actingAs($user)->post('/posts', $data);
        $response->assertSessionHasInput('body', 'something');
    }
}
