<?php

namespace Tests\Feature;

use App\Http\Livewire\Comment\Create;
use App\Models\Comment;
use App\Models\Post;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Livewire\Livewire;
use Tests\TestCase;

class CommentTest extends TestCase
{

    use RefreshDatabase;
    use WithFaker;

    /** @test  */
    public function show_post_contains_index_livewire_component()
    {

        [$user, $post] = $this->getFactory();

        Livewire::actingAs($user);

        $response = $this->get("/posts/{$post->id}");
        $response->assertSeeLivewire('comment.index');
        $response->assertStatus(200);
    }

    /** @test  */
    public function show_post_contains_create_livewire_component()
    {
        [$user, $post] = $this->getFactory();

        Livewire::actingAs($user);

        $response = $this->get("/posts/{$post->id}");
        $response->assertSeeLivewire('comment.index');
        $response->assertStatus(200);
    }

    /** @test  */
    public function show_post_contains_show_livewire_component()
    {
        [$user, $post] = $this->getFactory();

        Livewire::actingAs($user);

        $response = $this->get("/posts/{$post->id}");
        $response->assertSeeLivewire('comment.show');
        $response->assertStatus(200);
    }

    /** @test  */
    public function can_create_comment()
    {
        [$user, $post] = $this->getFactory();

        Livewire::actingAs($user);

        $response = Livewire::test('comment.create', ['post' => $post]);
        $response->set('comment', 'something');
        $response->assertSet('comment', 'something');
        $response->call('store');
        $response->assertStatus(200);

        $hasComment = Comment::whereBody('something')->exists();
        $this->assertTrue($hasComment);
    }

    /** @test  */
    public function comment_body_is_required()
    {
        [$user, $post] = $this->getFactory();

        Livewire::actingAs($user);

        $response = Livewire::test('comment.create', ['post' => $post]);
        $response->set('comment', '');

        $response->call('store');
        $response->assertHasErrors(['comment' => 'required']);
    }

    /** @test */
    public function can_update_comment()
    {
        [$user, $post, $comment] = $this->getFactory();

        Livewire::actingAs($user);

        Livewire::test('comment.show', ['comment' => $comment])
            ->set('comment_body', 'changed')
            ->assertSet('comment_body', 'changed')
            ->call('update')
            ->assertHasNoErrors(['comment_body' => 'required'])
            ->assertEmitted('refresh-comment')
            ->assertDispatchedBrowserEvent('swal:update-comment');

        $this->assertDatabaseHas('comments', ['body' => 'changed']);
        $this->assertDatabaseMissing('comments', ['body' => $comment->body]);
    }

    /** @test */
    public function comment_body_is_required_on_updated()
    {
        [$user, $post, $comment] = $this->getFactory();

        Livewire::actingAs($user);

        Livewire::test('comment.show', ['comment' => $comment])
            ->set('comment_body', '')
            ->call('update')
            ->assertHasErrors(['comment_body' => 'required']);
    }

    /** @test */
    public function unauthorized_user_cannot_update()
    {
        [$user, $post, $comment] = $this->getFactory();

        Livewire::test('comment.show', ['comment' => $comment])
            ->set('comment_body', 'something')
            ->call('update')
            ->assertForbidden();
    }

    /** @test */
    public function can_delete_comment()
    {
        [$user, $post, $comment] = $this->getFactory();

        Livewire::actingAs($user);

        $this->assertDatabaseCount('comments', 1);

        Livewire::test('comment.show', ['comment' => $comment])
            ->call('destroy')
            ->assertEmitted('refresh-comment');

        $this->assertDeleted($comment);
    }

    /** @test */
    public function unauthorized_user_cannot_delete_comment()
    {
        [$user, $post, $comment] = $this->getFactory();

        Livewire::actingAs(User::factory()->create());

        $this->assertDatabaseCount('comments', 1);

        Livewire::test('comment.show', ['comment' => $comment])
            ->call('destroy')
            ->assertForbidden();

        $this->assertDatabaseCount('comments', 1);
    }


    protected function getFactory()
    {
        $user = User::factory()->create();
        $post = Post::factory()->for($user)->create();
        $comment = Comment::factory()->create([
            'user_id' => $user->id,
            'post_id' => $post->id
        ]);

        return [$user, $post, $comment];
    }
}
