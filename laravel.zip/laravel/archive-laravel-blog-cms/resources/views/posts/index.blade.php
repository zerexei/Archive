<x-guest-layout>
    <div class="min-h-screen bg-gray-100">
        @auth
        @include('layouts.navigation')
        @endauth

        <!-- Page Heading -->
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between">
                    <h3>{{__('All posts')}}</h3>
                    <a href="{{route('posts.create')}}"
                        class="mx-2 px-4 py-2 text-sm rounded text-white bg-blue-500 focus:outline-none hover:bg-blue-400">
                        Create new post
                    </a>
                </div>
            </div>
        </header>

        <!-- Page Content -->
        <main>
            <div class=" py-12">
                <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6 bg-white border-b border-gray-200">

                            <div class="flex justify-center flex-wrap gap-5 lg:justify-start lg:gap-0 mb-6">
                                @forelse ($posts as $post)
                                <div class="w-full md:w-2/5 lg:w-1/4 overflow-hidden">
                                    <div class="px-4 py-4">
                                        {{-- POST TITLE --}}
                                        <h2 class="font-semibold text-gray-800 my-2 hover:underline text-lg">
                                            <a href="{{route('posts.show', $post)}}">{{$post->title}}</a>
                                        </h2>

                                        {{-- POST BODY --}}
                                        <p class="mb-6 text-sm text-gray-700">
                                            {{$post->body}}
                                        </p>

                                        {{-- POST TAGS & CREATED DATE --}}
                                        <div class="mb-2 text-xs text-gray-600 font-medium">
                                            {{-- TODO: Create a tags --}}
                                            <a href="#" class="uppercase hover:underline">
                                                Life
                                            </a>
                                            <span class="mx-1">&bull;</span>
                                            <span>{{$post->createdAt}}</span>
                                        </div>

                                        {{-- POST AUTHOR --}}
                                        <div class="text-sm text-gray-800">
                                            <a href="#">
                                                <img class="w-8 h-8 rounded-full inline-block mr-2"
                                                    src="https://picsum.photos/400" alt="User Avatar" />
                                            </a>
                                            by <a href="#"
                                                class="text-blue-500 hover:underline">{{$post->author_name}}</a>
                                        </div>
                                    </div>
                                </div>

                                @empty
                                <p>There is no available post.</p>
                                @endforelse
                            </div>

                            {{$posts->links()}}
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</x-guest-layout>
