<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Post') }}
        </h2>
    </x-slot>


    <div class="mb-12 px-4 pb-4 pt-2">
        {{-- POST HEADER --}}
        <div class="flex justify-between">
            <h2 class="font-semibold text-gray-800 my-2 hover:underline text-lg">
                <a href="#">{{$post->title}}</a>
            </h2>

            <div class="flex gap-2 text-xs items-start">
                <a href="{{route('posts.edit', $post)}}"
                    class="text-blue-400 hover:text-blue-500 hover:underline">Edit</a>
                <button onclick="document.querySelector('#deletePost').submit()"
                    class="text-red-400 hover:text-red-500 hover:underline">
                    Delete
                </button>

                <form id="deletePost" action="{{route('posts.destroy', $post)}}" method="POST" class="hidden">
                    @csrf
                    @method('DELETE')
                </form>
            </div>
        </div>

        {{-- POST BODY --}}
        <p class="mb-6 text-sm text-gray-700">
            {{$post->body}}
        </p>

        {{-- POST TAGS & CREATED DATE --}}
        <div class="mb-2 text-xs text-gray-600 font-medium">
            {{-- TODO: Create a tags --}}
            <a href="#" class="uppercase hover:underline">
                Life
            </a>
            <span class="mx-1">&bull;</span>
            <span>{{$post->createdAt}}</span>
        </div>

        {{-- POST AUTHOR --}}
        <div class="text-sm text-gray-800">
            <a href="#">
                <img class="w-8 h-8 rounded-full inline-block mr-2" src="https://picsum.photos/400" alt="User Avatar" />
            </a>
            by <a href="#" class="text-blue-500 hover:underline">{{$post->author_name}}</a>
        </div>
    </div>

    <div class="w-1/2">
        @livewire('comment.index', ['post' => $post])
    </div>
</x-app-layout>
