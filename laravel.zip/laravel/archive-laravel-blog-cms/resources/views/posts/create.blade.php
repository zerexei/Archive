<x-app-layout>

    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Create a post') }}
        </h2>
    </x-slot>


    <div class="w-1/3 mx-auto">

        <form action="{{route('posts.store')}}" method="POST">
            @csrf

            <div class="mb-6">
                <label for="title" class="block mb-1 text-sm font-bold text-gray-500">Title</label>
                <input value="{{old('title')}}" type="text" name="title" placeholder="title..." id="title"
                    class="w-full p-2 border rounded">
            </div>

            <div class="mb-6">
                <label for="body" class="block mb-1 text-sm font-bold text-gray-500">body</label>
                <textarea name="body" placeholder="write something..." id="body"
                    class="w-full p-2 border rounded">{{old('body')}}</textarea>
            </div>

            <div class="mb-6">
                <button
                    class="w-full px-4 py-2 text-sm rounded text-white bg-blue-500 focus:outline-none hover:bg-blue-400">
                    Submit
                </button>
            </div>
        </form>
    </div>
</x-app-layout>
