<div>
    {{-- Care about people's approval and you will be their prisoner. --}}
    <div class="flex flex-col gap-5 mb-6 text-sm">
        @foreach ($post->comments as $comment)
            @livewire('comment.show', ['comment' => $comment], key($comment->id))
        @endforeach
    </div>

    @livewire('comment.create', ['post' => $post])
</div>
