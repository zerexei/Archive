<div>
    {{-- If your happiness depends on money, you will never be happy with yourself. --}}
    <div class="mb-2 w-full">

        {{-- COMMENT --}}
        <textarea wire:model.lazy="comment_body" @if(!$isEdit) disabled @endif
            class="h-32 border mb-2 w-full resize-none text-sm rounded">{{ $comment_body }}</textarea>
            @error('comment_body') <span class="text-sm text-red-400">{{ $message }}</span> @enderror

            {{-- UPDATE OPTIONS --}}
        @if ($isEdit)
        <div class="flex justify-end gap-2">
            <button wire:click="toggleEditOption" class="text-xs text-red-400 hover:text-red-500 hover:underline">Cancel
            </button>
            <button wire:click="update"
                class="px-4 py-2 text-sm rounded text-white bg-blue-500 focus:outline-none hover:bg-blue-400">Update
            </button>
        </div>
        @endif
    </div>

    <div class="text-xs flex justify-between items-center">
        {{-- AUTHOR --}}
        <span>commented by:
            <a href="#" class="text-blue-400">
                {{ $user_name }}
            </a>
        </span>

        {{-- EDIT | DELETE --}}
        @if (!$isEdit)
        @can('update-comment', $comment)
        <div class="text-right text-xs">
            <button wire:click="toggleEditOption" class="text-blue-400">Edit</button>
            <button wire:click="showConfirmDelete" class="text-red-400 ml-2">Delete</button>
        </div>
        @endcan
        @endif
    </div>
</div>
