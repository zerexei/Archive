@auth
<div>
    {{-- The best athlete wants his opponent at his best. --}}
    <form action="#" method="POST" wire:submit.prevent="store">
        <div class="mb-2">
            <textarea wire:model.lazy="comment" name="comment" id="comment" class="w-full p-2 border rounded"
                placeholder="comment something..."></textarea>
            @error('comment') <span class="text-sm text-red-400">{{ $message }}</span> @enderror
        </div>
        <div class="mb-6 text-right">
            <button
                class="px-4 py-2 text-sm rounded text-white bg-blue-500 focus:outline-none hover:bg-blue-400">Comment</button>
        </div>
    </form>
</div>
@endauth
