<?php

namespace App\Models;

use App\Enums\PostState;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;

class Post extends Model
{
    use HasFactory, Searchable;

    protected $fillable = ["title", "body", "state"];

    // https://laravel.com/docs/9.x/eloquent-mutators#attribute-casting
    protected $casts = [
        "state" => PostState::class
    ];

    // https://laravel.com/docs/9.x/eloquent-serialization#appending-values-to-json
    protected $appends = ["path"];

    public function user()
    {
        return $this->belongsTo(User::class);
    }




    #[SearchUsingFullText('body')] // php attribute
    public function toSearchableArray()
    {
        // WHERE LIKE search
        return [
            "title" => $this->title,
            "body" => $this->body
        ];
    }
}
