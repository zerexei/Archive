<?php

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
| php artisan route:cache -> cache the route for better performance
| php artisan route:clear -> clear the cached routes
*/

$route = Route::current(); // Illuminate\Routing\Route
$name = Route::currentRouteName(); // string
$action = Route::currentRouteAction(); // string

Route::get('/', function () {
    return view('welcome');
});

// optional parameter
Route::get('/test/optional/{name?}', function (string $name = 'null') {
    return $name;
});

// regex parameter
Route::get('/test/regex/{id}', function (int $id) {
    return $id;
})->where(['id' => '[0-9]+']);

//! tested but doesn't work on me
// allow forward slashes (since laravel routing component doesn't allow `/`)
Route::get('/test/encoded/{search}', function ($search) {
    return $search;
})->where('search', '.*');

// named routes
Route::get('/test/named/{name}', function ($name) {
    return "Your name is {$name}";
})->name('user.name');
// usage: route('user/name, ['name' => $user->name, 'age' => $usser->age)
// same as:  /test/named/$user->name?age=$user->age

// GROUPED

// group middleware
Route::middleware('auth')->group(function () {
    Route::get('/grouped/middleware/1', function () {
    });
    Route::get('/grouped/middleware/2', function () {
    });
});

// prefix an url
Route::prefix('/admin')->group(function () {
    Route::get('/dashboard', function () {
    }); // /admin/dashboard
    Route::get('/settings', function () {
    }); // /admin/settings
});

// grouped named routes
Route::name('root.')->group(function () {
    Route::get('/{user}', fn ($name) => $name)->name('users');
});

// // laravel route model binding
// Route::get('/users/{user}', function (User $user) {
//     return $user->email;
// });

// // retrieve from soft deletes
// Route::get('/users/{user}', function (User $user) {
//     return $user->email;
// })->withTrashed();

// // using a slug: can be an emai,username or any key
// Route::get('/posts/{post:slug}', function (Post $post) {
//     return $post;
// });

// // implicit binding
// // laravel assume that the second eloquent model is a child of the parent model
// // laravel wish search for a posts(plural of post from wildcard) relationship
// Route::get('/users/{user}/posts/{post:slug}', function (User $user, Post $post) {
//     return $post;
// });

// // enable child bindings
// Route::get('/users/{user}/posts/{post}', function (User $user, Post $post) {
//     return $post;
// })->scopeBindings();

// if the model is not found, the missing method accepts a closure
Route::get('locations/{location}', function ($location) {
    return $location;
})->missing(function () {
    return Redirect::route('locations.index');
});

// unhandled requests
Route::fallback(function () {
    return "404";
});
