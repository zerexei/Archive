404.blade.php

custom 404 style
