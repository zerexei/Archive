<x-master>
  <div class="p-4 bg-gray-700 rounded shadow">
    <div class="w-2/3 mx-auto py-12">

      <h2 class="text-6xl text-white font-bold uppercase">Insta-Clone</h2>
      <p class="font-medium text-teal-400">Lorem ipsum dolor sit, amet consectetur
        adipisicing elit. Harum, recusandae
        inventore ratione perferendis beatae autem
        hic quaerat dolorem tempora. Perferendis
        voluptas porro dignissimos unde iste quaerat
        tempora officiis, voluptate itaque.</p>
      </div>
    </div>
</x-master>